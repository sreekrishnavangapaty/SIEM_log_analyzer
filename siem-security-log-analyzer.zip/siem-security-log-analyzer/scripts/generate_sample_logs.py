import os
import random
import argparse
from datetime import datetime, timedelta

def setup_argparse():
    parser = argparse.ArgumentParser(description="Generate sample logs for SIEM.")
    parser.add_argument('--scenario', choices=['normal', 'brute_force', 'account_enumeration', 'suspicious_login', 'mixed'],
                        default='mixed', help='Scenario to generate')
    return parser

def random_ip():
    return f"192.168.1.{random.randint(1, 254)}"

def generate_auth_line(dt, hostname, msg):
    ts = dt.strftime("%b %e %H:%M:%S")
    return f"{ts} {hostname} sshd[{random.randint(1000, 9999)}]: {msg}"

def generate_sys_line(dt, hostname, proc, msg):
    ts = dt.strftime("%b %e %H:%M:%S")
    return f"{ts} {hostname} {proc}[{random.randint(1000, 9999)}]: {msg}"

def generate_win_line(dt, evt_id, evt_type, user, ip, host, msg):
    ts = dt.strftime("%Y-%m-%dT%H:%M:%S")
    return f"{ts},{evt_id},{evt_type},{user},{ip},{host},{msg}"

def main():
    parser = setup_argparse()
    args = parser.parse_args()
    
    random.seed(42) # Deterministic
    start_time = datetime(2023, 10, 3, 8, 0, 0)
    
    auth_logs = []
    sys_logs = []
    win_logs = ["Timestamp,EventID,EventType,Username,SourceIP,ComputerName,Message"]
    
    users = ['admin', 'jdoe', 'asmith']
    host = 'server01'
    
    def add_normal(count):
        curr_time = start_time
        for _ in range(count):
            curr_time += timedelta(minutes=random.randint(1, 10))
            u = random.choice(users)
            ip = random_ip()
            auth_logs.append((curr_time, generate_auth_line(curr_time, host, f"Accepted password for {u} from {ip}")))
            sys_logs.append((curr_time, generate_sys_line(curr_time, host, "systemd", "Starting session...")))
            win_logs.append((curr_time, generate_win_line(curr_time, '4624', 'Success Audit', u, ip, host, 'An account was successfully logged on.')))
            
            curr_time += timedelta(minutes=random.randint(30, 120))
            auth_logs.append((curr_time, generate_auth_line(curr_time, host, f"session closed for user {u}")))
            win_logs.append((curr_time, generate_win_line(curr_time, '4634', 'Success Audit', u, ip, host, 'An account was logged off.')))

    def add_brute_force():
        curr_time = start_time + timedelta(hours=2)
        ip = "10.0.0.55"
        for _ in range(18):
            curr_time += timedelta(seconds=random.randint(1, 3))
            auth_logs.append((curr_time, generate_auth_line(curr_time, host, f"Failed password for admin from {ip}")))
            win_logs.append((curr_time, generate_win_line(curr_time, '4625', 'Failure Audit', 'admin', ip, host, 'An account failed to log on.')))
            
    def add_account_enumeration():
        curr_time = start_time + timedelta(hours=4)
        ip = "10.0.0.66"
        targets = ['admin', 'root', 'test', 'guest', 'administrator', 'user', 'backup', 'oracle', 'postgres', 'www-data']
        for t in targets:
            curr_time += timedelta(seconds=random.randint(1, 5))
            auth_logs.append((curr_time, generate_auth_line(curr_time, host, f"Invalid user {t} from {ip}")))

    def add_suspicious_login():
        curr_time = start_time + timedelta(hours=6)
        ip = "10.0.0.77"
        u = 'jdoe'
        for _ in range(8):
            curr_time += timedelta(seconds=random.randint(2, 5))
            auth_logs.append((curr_time, generate_auth_line(curr_time, host, f"Failed password for {u} from {ip}")))
        curr_time += timedelta(seconds=10)
        auth_logs.append((curr_time, generate_auth_line(curr_time, host, f"Accepted password for {u} from {ip}")))
        
    scenarios = {
        'normal': [lambda: add_normal(200)],
        'brute_force': [lambda: add_normal(100), add_brute_force],
        'account_enumeration': [lambda: add_normal(100), add_account_enumeration],
        'suspicious_login': [lambda: add_normal(100), add_suspicious_login],
        'mixed': [lambda: add_normal(150), add_brute_force, add_account_enumeration, add_suspicious_login]
    }
    
    for action in scenarios[args.scenario]:
        action()
        
    auth_logs.sort(key=lambda x: x[0])
    sys_logs.sort(key=lambda x: x[0])
    win_tuple_logs = win_logs[1:]
    win_tuple_logs.sort(key=lambda x: x[0])
    
    out_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'sample_logs')
    os.makedirs(out_dir, exist_ok=True)
    
    with open(os.path.join(out_dir, 'auth.log'), 'w') as f:
        for _, line in auth_logs:
            f.write(line + '\n')
            
    with open(os.path.join(out_dir, 'system.log'), 'w') as f:
        for _, line in sys_logs:
            f.write(line + '\n')
            
    with open(os.path.join(out_dir, 'windows_security_sample.log'), 'w') as f:
        f.write(win_logs[0] + '\n')
        for _, line in win_tuple_logs:
            f.write(line + '\n')

    print(f"Generated {args.scenario} scenario logs in {out_dir}")
    print(f"Auth logs: {len(auth_logs)} lines")
    print(f"System logs: {len(sys_logs)} lines")
    print(f"Windows logs: {len(win_tuple_logs) + 1} lines")

if __name__ == '__main__':
    main()
