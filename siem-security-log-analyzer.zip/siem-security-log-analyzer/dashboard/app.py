"""
SIEM Security Log Analyzer — Streamlit Dashboard
A high-performance, dark-themed SOC/SIEM console for security event monitoring,
alert investigation, and threat analysis.
"""
import sys
import os
import io
import tempfile
from datetime import datetime
from pathlib import Path

# ── Ensure project root is on sys.path ───────────────────────────────────────
PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import streamlit as st
import pandas as pd

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
plt.style.use('dark_background')

# ── App imports ──────────────────────────────────────────────────────────────
from app.config import DATA_DIR, DB_PATH, DEMO_MODE
from app.database.connection import DatabaseConnection
from app.database.models import create_tables
from app.database.repository import Repository
from app.parsers.linux_auth_parser import LinuxAuthParser
from app.parsers.linux_system_parser import LinuxSystemParser
from app.parsers.windows_parser import WindowsSecurityParser
from app.parsers.normalizer import normalize_event
from app.ingestion.log_reader import LogReader
from app.detection.engine import DetectionEngine
from app.detection.correlation import CorrelationTracker
from app.detection.rules import get_all_rules, get_rule
from app.detection.thresholds import get_thresholds, update_threshold
from app.alerts.alert_manager import AlertManager
from app.analytics.statistics import SecurityStatistics
from app.analytics.trends import TrendAnalyzer
from app.sample_generator import SampleLogGenerator

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title='SIEM SOC Console',
    page_icon='🛡️',
    layout='wide',
    initial_sidebar_state='expanded',
)

# ── Custom CSS for High-Tech SOC Console ─────────────────────────────────────
st.markdown('''
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<style>
    /* Global styles */
    .stApp {
        background: radial-gradient(circle at 10% 10%, #0d1527 0%, #070b14 100%);
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        color: #e2e8f0;
    }
    .block-container {
        padding-top: 1.2rem;
        padding-bottom: 2rem;
        max-width: 98%;
    }

    /* Sidebar Styling */
    section[data-testid="stSidebar"] {
        background-color: #0b1120;
        border-right: 1px solid rgba(255, 255, 255, 0.07);
    }
    
    /* Metric Cards */
    div[data-testid="stMetric"] {
        background: linear-gradient(135deg, rgba(30, 41, 59, 0.7) 0%, rgba(15, 23, 42, 0.8) 100%);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        padding: 14px 18px;
        box-shadow: 0 4px 15px -1px rgba(0, 0, 0, 0.3);
        transition: transform 0.15s ease, border-color 0.15s ease;
    }
    div[data-testid="stMetric"]:hover {
        border-color: rgba(56, 189, 248, 0.4);
        transform: translateY(-2px);
    }
    div[data-testid="stMetric"] label {
        color: #94a3b8;
        font-size: 0.8rem;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    div[data-testid="stMetric"] div[data-testid="stMetricValue"] {
        color: #f8fafc;
        font-family: 'JetBrains Mono', monospace;
        font-weight: 700;
        font-size: 1.75rem;
    }

    /* Badges & Chips */
    .badge {
        display: inline-block;
        padding: 3px 8px;
        border-radius: 6px;
        font-size: 0.75rem;
        font-weight: 600;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        font-family: 'JetBrains Mono', monospace;
    }
    .badge-critical {
        background: rgba(239, 68, 68, 0.15);
        color: #f87171;
        border: 1px solid rgba(239, 68, 68, 0.45);
    }
    .badge-high {
        background: rgba(249, 115, 22, 0.15);
        color: #fb923c;
        border: 1px solid rgba(249, 115, 22, 0.45);
    }
    .badge-medium {
        background: rgba(234, 179, 8, 0.15);
        color: #facc15;
        border: 1px solid rgba(234, 179, 8, 0.45);
    }
    .badge-low {
        background: rgba(16, 185, 129, 0.15);
        color: #34d399;
        border: 1px solid rgba(16, 185, 129, 0.45);
    }
    
    .status-pill {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.72rem;
        font-weight: 600;
        letter-spacing: 0.03em;
        font-family: 'JetBrains Mono', monospace;
    }
    .status-new {
        background: rgba(244, 63, 94, 0.15);
        color: #fb7185;
        border: 1px solid rgba(244, 63, 94, 0.4);
    }
    .status-investigating {
        background: rgba(56, 189, 248, 0.15);
        color: #38bdf8;
        border: 1px solid rgba(56, 189, 248, 0.4);
    }
    .status-resolved {
        background: rgba(16, 185, 129, 0.15);
        color: #34d399;
        border: 1px solid rgba(16, 185, 129, 0.4);
    }
    .status-false_positive {
        background: rgba(148, 163, 184, 0.15);
        color: #94a3b8;
        border: 1px solid rgba(148, 163, 184, 0.4);
    }

    .cyber-chip {
        font-family: 'JetBrains Mono', monospace;
        background: #111c30;
        color: #38bdf8;
        padding: 2px 7px;
        border-radius: 4px;
        font-size: 0.8rem;
        border: 1px solid rgba(56, 189, 248, 0.25);
    }
    .user-chip {
        font-family: 'JetBrains Mono', monospace;
        background: #111c30;
        color: #e2e8f0;
        padding: 2px 7px;
        border-radius: 4px;
        font-size: 0.8rem;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .soc-header {
        background: linear-gradient(90deg, #131d33 0%, #0f172a 100%);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        padding: 16px 20px;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    
    .evidence-card {
        background: #090d16;
        border-left: 4px solid #f97316;
        border-radius: 0 8px 8px 0;
        padding: 14px 18px;
        font-family: 'JetBrains Mono', monospace;
        font-size: 0.84rem;
        color: #fdba74;
        line-height: 1.55;
        margin: 12px 0;
        border-top: 1px solid rgba(249, 115, 22, 0.2);
        border-bottom: 1px solid rgba(249, 115, 22, 0.2);
        border-right: 1px solid rgba(249, 115, 22, 0.2);
    }

    .alert-card-row {
        background: #111c30;
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: 8px;
        padding: 10px 14px;
        margin-bottom: 8px;
        transition: border-color 0.15s ease;
    }
    .alert-card-row:hover {
        border-color: rgba(56, 189, 248, 0.35);
    }

    /* Buttons */
    div.stButton > button {
        background: linear-gradient(135deg, #1e293b, #0f172a);
        color: #f8fafc;
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 6px;
        font-weight: 500;
        padding: 0.45rem 1.1rem;
        transition: all 0.15s ease;
    }
    div.stButton > button:hover {
        border-color: #38bdf8;
        color: #38bdf8;
        box-shadow: 0 0 12px rgba(56, 189, 248, 0.25);
    }
</style>
''', unsafe_allow_html=True)


# ── Initialize services (cached) ────────────────────────────────────────────
@st.cache_resource
def init_services():
    """Initialize all SIEM services once."""
    db = DatabaseConnection(DB_PATH)
    create_tables(db)
    repo = Repository(db)
    correlation = CorrelationTracker()
    engine = DetectionEngine(correlation)
    alert_mgr = AlertManager(repo)
    stats = SecurityStatistics(repo)
    trends = TrendAnalyzer(repo)
    return db, repo, engine, alert_mgr, stats, trends

db_conn, repo, detection_engine, alert_manager, stats, trends = init_services()

PARSERS = {
    'Linux Auth': LinuxAuthParser(),
    'Linux System': LinuxSystemParser(),
    'Windows Security': WindowsSecurityParser(),
}

# ── Badge formatting helpers ────────────────────────────────────────────────
def severity_badge(sev: str) -> str:
    s = (sev or 'LOW').upper()
    css_class = f"badge-{s.lower()}"
    return f'<span class="badge {css_class}">{s}</span>'

def status_badge(status: str) -> str:
    st_val = (status or 'NEW').upper()
    css_class = f"status-{st_val.lower()}"
    return f'<span class="status-pill {css_class}">{st_val}</span>'

def ip_chip(ip: str) -> str:
    if not ip:
        return '<span style="color:#64748b;">N/A</span>'
    return f'<span class="cyber-chip">{ip}</span>'

def user_chip(u: str) -> str:
    if not u:
        return '<span style="color:#64748b;">N/A</span>'
    return f'<span class="user-chip">{u}</span>'

# ── Matplotlib Aesthetic Styler ──────────────────────────────────────────────
def style_axes(fig, ax):
    """Applies modern dark SOC theme to Matplotlib axes."""
    fig.patch.set_facecolor('#0f172a')
    ax.set_facecolor('#0f172a')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#334155')
    ax.spines['bottom'].set_color('#334155')
    ax.tick_params(colors='#94a3b8', labelsize=8)
    ax.yaxis.label.set_color('#94a3b8')
    ax.xaxis.label.set_color('#94a3b8')
    ax.title.set_color('#e2e8f0')
    ax.grid(color='#1e293b', linestyle='--', linewidth=0.7, alpha=0.7)


# ══════════════════════════════════════════════════════════════════════════════
# PIPELINE EXECUTION FUNCTION
# ══════════════════════════════════════════════════════════════════════════════
def run_pipeline(lines, parser_name='Linux Auth'):
    """Run the full pipeline: parse -> normalize -> detect -> alert -> store.
    Returns processing statistics."""
    parser = PARSERS.get(parser_name, LinuxAuthParser())
    result = {
        'lines_processed': 0, 'events_parsed': 0, 'events_stored': 0,
        'alerts_generated': 0, 'errors': 0, 'new_alert_ids': [],
    }

    # Reset correlation for fresh detection in this batch
    detection_engine.correlation.reset()

    for line in lines:
        line = line.strip()
        if not line:
            continue
        result['lines_processed'] += 1

        try:
            parsed = parser.parse_line(line)
            if parsed is None:
                # Try auto-detect with other parsers
                for name, p in PARSERS.items():
                    if name != parser_name:
                        parsed = p.parse_line(line)
                        if parsed:
                            parser_name_used = p.parser_name
                            break
                else:
                    result['errors'] += 1
                    continue
                parser_name_used = p.parser_name
            else:
                parser_name_used = parser.parser_name

            result['events_parsed'] += 1

            normalized = normalize_event(parsed, parser_name_used, line)
            if normalized is None:
                result['errors'] += 1
                continue

            # Store event
            repo.insert_event(normalized)
            result['events_stored'] += 1

            # Detection
            detections = detection_engine.process_event(normalized)
            for det in detections:
                alert_id = alert_manager.process_detection(det)
                if alert_id:
                    result['alerts_generated'] += 1
                    result['new_alert_ids'].append(alert_id)

        except Exception:
            result['errors'] += 1

    return result


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR NAVIGATION
# ══════════════════════════════════════════════════════════════════════════════
st.sidebar.markdown('''
<div style="padding: 10px 0 15px 0;">
    <div style="font-size: 1.15rem; font-weight: 700; color: #f8fafc; letter-spacing: -0.02em;">
        🛡️ SIEM SOC Console
    </div>
    <div style="font-size: 0.72rem; color: #10b981; font-family: 'JetBrains Mono', monospace; margin-top: 3px;">
        ● SYSTEM OPERATIONAL
    </div>
</div>
''', unsafe_allow_html=True)

page = st.sidebar.radio(
    'Navigation',
    [
        'Overview',
        'Security Events',
        'Security Alerts',
        'Alert Investigation',
        'Threat Analysis',
        'Detection Rules',
        'Log Ingestion',
        'Reports',
        'Settings',
    ],
    label_visibility='collapsed',
)

st.sidebar.markdown('---')
auto_refresh = st.sidebar.toggle(
    '🔄 Live Refresh (5s)',
    value=True,
    help='Automatically polls SQLite and updates graphs & metrics every 5 seconds.',
)
if auto_refresh:
    st.sidebar.caption('🟢 Auto-refresh active (5s interval)')
else:
    st.sidebar.caption('⚪ Auto-refresh paused')

st.sidebar.markdown('---')
st.sidebar.caption(f"📁 DB: `{Path(DB_PATH).name}`")
if DEMO_MODE:
    st.sidebar.markdown('<span style="color:#38bdf8; font-size:0.75rem; font-weight:600;">● DEMO TELEMETRY ACTIVE</span>', unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 1: OVERVIEW
# ══════════════════════════════════════════════════════════════════════════════
if page == 'Overview':
    st.markdown('''
    <div class="soc-header">
        <div>
            <h2 style="margin: 0; color: #f8fafc; font-size: 1.45rem; font-weight: 700;">Security Operations Overview</h2>
            <div style="color: #94a3b8; font-size: 0.82rem; margin-top: 4px;">Live Threat Intelligence & Incident Telemetry</div>
        </div>
        <div style="text-align: right;">
            <span class="status-pill status-investigating">ACTIVE DEFENSE</span>
        </div>
    </div>
    ''', unsafe_allow_html=True)

    if DEMO_MODE:
        st.caption('ℹ️ Running in Demo Mode — real-time analysis over ingested synthetic and audit logs.')

    @st.fragment(run_every=5 if auto_refresh else None)
    def render_overview():
        now_str = datetime.now().strftime('%H:%M:%S')
        st.markdown(f'<div style="font-size:0.75rem; color:#64748b; font-family:\'JetBrains Mono\', monospace; margin-bottom: 10px;">⏱️ Telemetry Polling • Last synchronized: {now_str}</div>', unsafe_allow_html=True)

        try:
            overview = stats.get_overview()
        except Exception:
            overview = {
                'total_events': 0, 'total_alerts': 0, 'critical_alerts': 0,
                'high_alerts': 0, 'medium_alerts': 0, 'low_alerts': 0,
                'failed_logins': 0, 'successful_logins': 0, 'unique_ips': 0,
                'unique_usernames': 0, 'active_alerts': 0,
            }

        if overview['total_events'] == 0:
            st.info('🛡️ No telemetry recorded yet. Navigate to **Log Ingestion** to process security logs or generate an attack scenario.')

        # KPI Metrics Row
        c1, c2, c3, c4, c5, c6, c7 = st.columns(7)
        c1.metric('Total Events', f"{overview['total_events']:,}")
        c2.metric('Total Alerts', f"{overview['total_alerts']:,}")
        c3.metric('Critical', overview['critical_alerts'])
        c4.metric('High', overview['high_alerts'])
        c5.metric('Failed Logins', overview['failed_logins'])
        c6.metric('Auth Success', overview['successful_logins'])
        c7.metric('Unique IPs', overview['unique_ips'])

        st.markdown('<div style="height: 15px;"></div>', unsafe_allow_html=True)

        # Matplotlib Visualizations Row
        col_left, col_right = st.columns(2)

        with col_left:
            st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-bottom:8px;">📈 Ingestion Volume Over Time</div>', unsafe_allow_html=True)
            eot = stats.get_events_over_time()
            if eot:
                fig, ax = plt.subplots(figsize=(8, 3.6), dpi=120)
                style_axes(fig, ax)
                times = [e['time'] for e in eot]
                counts = [e['count'] for e in eot]
                labels = [t[-5:] if len(t) > 5 else t for t in times]
                ax.plot(labels, counts, color='#38bdf8', linewidth=2.2, marker='o', markersize=4.5, markerfacecolor='#0284c7')
                ax.fill_between(range(len(counts)), counts, alpha=0.18, color='#38bdf8')
                ax.set_ylabel('Events / Bucket', fontsize=8)
                ax.tick_params(axis='x', rotation=35, labelsize=7)
                fig.tight_layout()
                st.pyplot(fig)
                plt.close(fig)
            else:
                st.caption('No chronological event data available.')

        with col_right:
            st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-bottom:8px;">🚨 Alerts Classified by Severity</div>', unsafe_allow_html=True)
            abs_data = stats.get_alerts_by_severity()
            if abs_data:
                fig, ax = plt.subplots(figsize=(8, 3.6), dpi=120)
                style_axes(fig, ax)
                sevs = list(abs_data.keys())
                cnts = list(abs_data.values())
                colors_map = {
                    'CRITICAL': '#ef4444', 'HIGH': '#f97316',
                    'MEDIUM': '#eab308', 'LOW': '#10b981'
                }
                bar_colors = [colors_map.get(s, '#64748b') for s in sevs]
                bars = ax.bar(sevs, cnts, color=bar_colors, edgecolor='#334155', linewidth=0.8, width=0.55)
                ax.set_ylabel('Alert Count', fontsize=8)
                ax.yaxis.set_major_locator(mticker.MaxNLocator(integer=True))
                # Add values on top of bars
                for bar in bars:
                    height = bar.get_height()
                    if height > 0:
                        ax.annotate(f'{height}',
                                    xy=(bar.get_x() + bar.get_width() / 2, height),
                                    xytext=(0, 3), textcoords="offset points",
                                    ha='center', va='bottom', fontsize=8, color='#e2e8f0', fontweight='600')
                fig.tight_layout()
                st.pyplot(fig)
                plt.close(fig)
            else:
                st.caption('No severity alert data recorded.')

        # Recent Alerts Feed
        st.markdown('<div style="height: 15px;"></div>', unsafe_allow_html=True)
        st.markdown('<div style="font-size:1.05rem; font-weight:700; color:#f8fafc; margin-bottom:12px;">⚡ Live Security Incident Feed</div>', unsafe_allow_html=True)
        try:
            recent = repo.get_alerts(limit=8)
            if recent:
                for a in recent:
                    sev = a.get('severity', 'LOW')
                    status = a.get('status', 'NEW')
                    src_ip = a.get('source_ip', 'N/A')
                    user = a.get('username') or 'N/A'
                    time_seen = a.get('first_seen', '')[:19]
                    occ = a.get('occurrence_count', 1)
                    st.markdown(
                        f'''
                        <div class="alert-card-row">
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <div>
                                    {severity_badge(sev)} &nbsp;
                                    <span style="font-weight:600; color:#f1f5f9; font-size:0.9rem;">{a.get('rule_name', '')}</span> &nbsp;
                                    {status_badge(status)}
                                </div>
                                <div style="font-family:'JetBrains Mono', monospace; font-size:0.75rem; color:#64748b;">
                                    {time_seen} &nbsp; <span style="background:rgba(255,255,255,0.06); padding:2px 6px; border-radius:4px; color:#cbd5e1;">x{occ}</span>
                                </div>
                            </div>
                            <div style="margin-top:6px; font-size:0.83rem; color:#cbd5e1;">
                                Source: {ip_chip(src_ip)} &nbsp;|&nbsp; Target: {user_chip(user)} &nbsp;|&nbsp; 
                                <span style="color:#94a3b8;">{a.get('description', '')[:140]}</span>
                            </div>
                        </div>
                        ''',
                        unsafe_allow_html=True
                    )
            else:
                st.caption('No active security alerts in SQLite database.')
        except Exception:
            st.caption('Unable to query alert feed.')

    render_overview()


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 2: SECURITY EVENTS
# ══════════════════════════════════════════════════════════════════════════════
elif page == 'Security Events':
    st.markdown('''
    <div class="soc-header">
        <div>
            <h2 style="margin: 0; color: #f8fafc; font-size: 1.45rem; font-weight: 700;">Security Events Explorer</h2>
            <div style="color: #94a3b8; font-size: 0.82rem; margin-top: 4px;">Search, filter, and inspect normalized telemetry events</div>
        </div>
    </div>
    ''', unsafe_allow_html=True)

    # Filter toolbar
    fc1, fc2, fc3 = st.columns(3)
    with fc1:
        event_types = ['All', 'LOGIN_SUCCESS', 'LOGIN_FAILURE', 'INVALID_USER',
                        'LOGOUT', 'PRIVILEGE_CHANGE', 'SERVICE_START',
                        'SERVICE_STOP', 'SYSTEM_WARNING', 'SUSPICIOUS_ACCESS', 'UNKNOWN']
        sel_type = st.selectbox('Event Classification', event_types)
    with fc2:
        sel_ip = st.text_input('Filter by Source IP', '', placeholder='e.g. 10.0.0.50')
    with fc3:
        sel_user = st.text_input('Filter by Target Username', '', placeholder='e.g. admin')

    filters = {}
    if sel_type != 'All':
        filters['event_type'] = sel_type
    if sel_ip.strip():
        filters['source_ip'] = sel_ip.strip()
    if sel_user.strip():
        filters['username'] = sel_user.strip()

    try:
        events = repo.get_events(limit=500, **filters)
        st.markdown(f"<div style='font-size:0.8rem; color:#94a3b8; margin: 8px 0;'>Displaying <b>{len(events)}</b> matching events</div>", unsafe_allow_html=True)

        if events:
            df = pd.DataFrame(events)
            display_cols = [c for c in ['timestamp', 'event_type', 'username',
                            'source_ip', 'hostname', 'severity', 'message'] if c in df.columns]
            st.dataframe(
                df[display_cols],
                use_container_width=True,
                height=550,
                column_config={
                    'timestamp': st.column_config.TextColumn('Timestamp', width='medium'),
                    'event_type': st.column_config.TextColumn('Type', width='small'),
                    'username': st.column_config.TextColumn('Account', width='small'),
                    'source_ip': st.column_config.TextColumn('Source IP', width='small'),
                    'severity': st.column_config.TextColumn('Severity', width='small'),
                    'message': st.column_config.TextColumn('Event Message', width='large'),
                }
            )
        else:
            st.info('No events found matching the specified search criteria.')
    except Exception as e:
        st.error(f'Error querying events: {e}')


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 3: SECURITY ALERTS
# ══════════════════════════════════════════════════════════════════════════════
elif page == 'Security Alerts':
    st.markdown('''
    <div class="soc-header">
        <div>
            <h2 style="margin: 0; color: #f8fafc; font-size: 1.45rem; font-weight: 700;">Security Incident Alerts</h2>
            <div style="color: #94a3b8; font-size: 0.82rem; margin-top: 4px;">Deduplicated threats flagged by detection correlation rules</div>
        </div>
    </div>
    ''', unsafe_allow_html=True)

    fc1, fc2, fc3, fc4 = st.columns(4)
    with fc1:
        sel_sev = st.selectbox('Severity Level', ['All', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'])
    with fc2:
        sel_rule = st.selectbox('Detection Rule', ['All'] + [r.rule_name for r in get_all_rules()])
    with fc3:
        sel_status = st.selectbox('Incident Status', ['All', 'NEW', 'INVESTIGATING', 'RESOLVED', 'FALSE_POSITIVE'])
    with fc4:
        sel_ip_alert = st.text_input('Source IP Search', '', placeholder='e.g. 10.0.0.50', key='alert_ip')

    filters = {}
    if sel_sev != 'All':
        filters['severity'] = sel_sev
    if sel_rule != 'All':
        filters['rule_name'] = sel_rule
    if sel_status != 'All':
        filters['status'] = sel_status
    if sel_ip_alert.strip():
        filters['source_ip'] = sel_ip_alert.strip()

    try:
        alerts = repo.get_alerts(limit=500, **filters)
        st.markdown(f"<div style='font-size:0.8rem; color:#94a3b8; margin: 8px 0;'>Displaying <b>{len(alerts)}</b> correlated alerts</div>", unsafe_allow_html=True)

        if alerts:
            for a in alerts:
                sev = a.get('severity', 'LOW')
                status = a.get('status', 'NEW')
                src_ip = a.get('source_ip', 'N/A')
                user = a.get('username') or 'N/A'
                aid = a.get('alert_id', 'ALT')
                occ = a.get('occurrence_count', 1)
                first_seen = a.get('first_seen', '')[:19]
                last_seen = a.get('last_seen', '')[:19]

                st.markdown(
                    f'''
                    <div class="alert-card-row">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <div>
                                <span style="font-family:'JetBrains Mono', monospace; font-size:0.82rem; font-weight:700; color:#38bdf8;">{aid}</span> &nbsp;
                                {severity_badge(sev)} &nbsp;
                                <span style="font-weight:600; color:#f8fafc; font-size:0.92rem;">{a.get('rule_name', '')}</span> &nbsp;
                                {status_badge(status)}
                            </div>
                            <div>
                                <span style="font-size:0.75rem; color:#94a3b8; font-family:'JetBrains Mono', monospace;">
                                    Occurrences: <b style="color:#f8fafc;">x{occ}</b> &nbsp;|&nbsp; Last Seen: {last_seen}
                                </span>
                            </div>
                        </div>
                        <div style="margin-top:6px; font-size:0.82rem; color:#cbd5e1;">
                            Source IP: {ip_chip(src_ip)} &nbsp;|&nbsp; Target User: {user_chip(user)} &nbsp;|&nbsp;
                            <span style="color:#94a3b8;">{a.get('description', '')[:150]}</span>
                        </div>
                    </div>
                    ''',
                    unsafe_allow_html=True
                )
        else:
            st.info('No alerts match the chosen filter configuration.')
    except Exception as e:
        st.error(f'Error loading alerts: {e}')


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 4: ALERT INVESTIGATION
# ══════════════════════════════════════════════════════════════════════════════
elif page == 'Alert Investigation':
    st.markdown('''
    <div class="soc-header">
        <div>
            <h2 style="margin: 0; color: #f8fafc; font-size: 1.45rem; font-weight: 700;">Incident Investigation Dossier</h2>
            <div style="color: #94a3b8; font-size: 0.82rem; margin-top: 4px;">Deep-dive forensic evidence, timeline correlation, and threat triage</div>
        </div>
    </div>
    ''', unsafe_allow_html=True)

    try:
        all_alerts = repo.get_alerts(limit=200)
    except Exception:
        all_alerts = []

    if not all_alerts:
        st.info('🛡️ No alerts available for investigation. Ingest logs or trigger a demo scenario to generate security alerts.')
    else:
        alert_options = {
            f"[{a.get('severity','LOW')}] {a['alert_id']} — {a.get('rule_name','')} (Src: {a.get('source_ip','N/A')})"
            : a['alert_id']
            for a in all_alerts
        }
        selected_label = st.selectbox('Select Target Alert to Investigate', list(alert_options.keys()))
        selected_id = alert_options[selected_label]

        alert = alert_manager.get_alert_details(selected_id)
        if alert:
            # Top Alert Header
            st.markdown(f'''
            <div style="background:#0f172a; border:1px solid rgba(56, 189, 248, 0.25); border-radius:8px; padding:12px 18px; margin-bottom:18px;">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <div>
                        <span style="font-size:1.1rem; font-weight:700; color:#f8fafc; font-family:'JetBrains Mono', monospace;">{alert.get('alert_id', '')}</span> &nbsp;
                        {severity_badge(alert.get('severity',''))} &nbsp;
                        <span style="font-size:1.05rem; font-weight:600; color:#e2e8f0;">{alert.get('rule_name', '')}</span>
                    </div>
                    <div>
                        Current Status: {status_badge(alert.get('status',''))}
                    </div>
                </div>
            </div>
            ''', unsafe_allow_html=True)

            inv_col1, inv_col2 = st.columns([1, 1])

            with inv_col1:
                st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-bottom:8px;">📋 Forensic Target Metadata</div>', unsafe_allow_html=True)
                ic1, ic2, ic3 = st.columns(3)
                ic1.metric('Source IP', alert.get('source_ip', 'N/A'))
                ic2.metric('Target Account', alert.get('username', 'N/A'))
                ic3.metric('Total Frequency', f"x{alert.get('occurrence_count', 1)}")

                tc1, tc2 = st.columns(2)
                tc1.metric('First Observed', str(alert.get('first_seen', ''))[:19])
                tc2.metric('Last Observed', str(alert.get('last_seen', ''))[:19])

                st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-top:16px; margin-bottom:6px;">🔎 Detection Engine Evidence</div>', unsafe_allow_html=True)
                evidence = alert.get('evidence', 'No structured evidence recorded.')
                st.markdown(f'<div class="evidence-card">{evidence}</div>', unsafe_allow_html=True)

                # Status Transition Control
                st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-top:16px; margin-bottom:6px;">⚖️ Analyst Disposition Workflow</div>', unsafe_allow_html=True)
                current_status = alert.get('status', 'NEW')
                new_status = st.selectbox(
                    'Transition Incident Status',
                    ['NEW', 'INVESTIGATING', 'RESOLVED', 'FALSE_POSITIVE'],
                    index=['NEW', 'INVESTIGATING', 'RESOLVED', 'FALSE_POSITIVE'].index(current_status),
                    help='Persists incident status directly to the SQLite database.'
                )
                if st.button('Confirm Status Update'):
                    if alert_manager.update_status(selected_id, new_status):
                        st.success(f'Alert {selected_id} updated to {new_status}.')
                        st.rerun()
                    else:
                        st.error('Failed to update alert status.')

            with inv_col2:
                st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-bottom:8px;">🛡️ SOC Analyst Response Playbook</div>', unsafe_allow_html=True)
                rule = get_rule(alert.get('rule_id', ''))
                guidance_md = (
                    f"1. **Host Verification**: Query internal asset inventory to determine if source IP `{alert.get('source_ip', 'N/A')}` belongs to an internal employee, VPN exit, or external threat actor.\n"
                    f"2. **Credential Audit**: Check if user `{alert.get('username', 'N/A')}` is active, suspended, or a shared service account.\n"
                    "3. **Multi-Stage Correlation**: Review all network logs from this IP within +/- 300 seconds of the incident.\n"
                    f"4. **Remediation Action**: If confirmed malicious, submit firewall block ticket for `{alert.get('source_ip', 'N/A')}` and issue credential reset.\n"
                    "5. **False Positive Handling**: If legitimate forgotten password recovery, document and mark `FALSE_POSITIVE`."
                )
                st.info(guidance_md)

                st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-top:16px; margin-bottom:8px;">🔗 Correlated Contributing Events</div>', unsafe_allow_html=True)
                related = repo.get_events_for_alert(
                    source_ip=alert.get('source_ip'),
                    username=alert.get('username') if alert.get('username') else None,
                    start_time=alert.get('first_seen'),
                    end_time=alert.get('last_seen'),
                )
                if related:
                    df_rel = pd.DataFrame(related)
                    display_cols = [c for c in ['timestamp', 'event_type', 'username', 'severity', 'message'] if c in df_rel.columns]
                    st.dataframe(df_rel[display_cols], use_container_width=True, height=220)
                else:
                    st.caption('No directly linked events found in this exact time bracket.')


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 5: THREAT ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════
elif page == 'Threat Analysis':
    st.markdown('''
    <div class="soc-header">
        <div>
            <h2 style="margin: 0; color: #f8fafc; font-size: 1.45rem; font-weight: 700;">Threat Vector & Attack Analysis</h2>
            <div style="color: #94a3b8; font-size: 0.82rem; margin-top: 4px;">Pattern distribution, top threat origins, and authentication metrics</div>
        </div>
    </div>
    ''', unsafe_allow_html=True)

    @st.fragment(run_every=5 if auto_refresh else None)
    def render_threat_analysis():
        now_str = datetime.now().strftime('%H:%M:%S')
        st.markdown(f'<div style="font-size:0.75rem; color:#64748b; font-family:\'JetBrains Mono\', monospace; margin-bottom: 12px;">⏱️ Threat Intelligence Polling • Last synchronized: {now_str}</div>', unsafe_allow_html=True)

        col_l, col_r = st.columns(2)

        with col_l:
            st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-bottom:8px;">🎯 Top Suspicious Adversary IPs</div>', unsafe_allow_html=True)
            sus = stats.get_top_suspicious_ips(limit=8)
            if sus:
                fig, ax = plt.subplots(figsize=(7, 3.8), dpi=120)
                style_axes(fig, ax)
                ips = [s['ip'] for s in sus][::-1]
                counts = [s['count'] for s in sus][::-1]
                bars = ax.barh(ips, counts, color='#f43f5e', edgecolor='#334155', height=0.6)
                ax.set_xlabel('Failed Authentication Volume', fontsize=8)
                ax.xaxis.set_major_locator(mticker.MaxNLocator(integer=True))
                for bar in bars:
                    width = bar.get_width()
                    if width > 0:
                        ax.annotate(f'{width}',
                                    xy=(width, bar.get_y() + bar.get_height() / 2),
                                    xytext=(5, 0), textcoords="offset points",
                                    ha='left', va='center', fontsize=8, color='#f8fafc', fontweight='600')
                fig.tight_layout()
                st.pyplot(fig)
                plt.close(fig)
            else:
                st.caption('No suspicious IP telemetry recorded.')

        with col_r:
            st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-bottom:8px;">⚖️ Authentication Ratio (Success vs Failure)</div>', unsafe_allow_html=True)
            auth = stats.get_auth_distribution()
            if auth and (auth.get('success', 0) + auth.get('failure', 0)) > 0:
                fig, ax = plt.subplots(figsize=(7, 3.8), dpi=120)
                style_axes(fig, ax)
                labels = ['Success', 'Failure']
                sizes = [auth['success'], auth['failure']]
                colors = ['#10b981', '#f43f5e']
                # Donut chart
                wedges, texts, autotexts = ax.pie(
                    sizes, labels=labels, colors=colors, autopct='%1.1f%%',
                    startangle=140, pctdistance=0.75,
                    textprops={'color': '#cbd5e1', 'fontsize': 9},
                    wedgeprops={'width': 0.45, 'edgecolor': '#0f172a', 'linewidth': 2}
                )
                for autotext in autotexts:
                    autotext.set_color('#ffffff')
                    autotext.set_fontweight('bold')
                fig.tight_layout()
                st.pyplot(fig)
                plt.close(fig)
            else:
                st.caption('No authentication metrics recorded.')

        col_l2, col_r2 = st.columns(2)

        with col_l2:
            st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-bottom:8px;">📊 Security Event Type Breakdown</div>', unsafe_allow_html=True)
            etd = stats.get_event_type_distribution()
            if etd:
                fig, ax = plt.subplots(figsize=(7, 3.8), dpi=120)
                style_axes(fig, ax)
                types = [e['type'] or 'UNKNOWN' for e in etd]
                counts = [e['count'] for e in etd]
                bars = ax.bar(types, counts, color='#6366f1', edgecolor='#334155', width=0.55)
                ax.set_ylabel('Total Events', fontsize=8)
                ax.tick_params(axis='x', rotation=35, labelsize=7.5)
                ax.yaxis.set_major_locator(mticker.MaxNLocator(integer=True))
                fig.tight_layout()
                st.pyplot(fig)
                plt.close(fig)
            else:
                st.caption('No event classification distribution.')

        with col_r2:
            st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-bottom:8px;">⚡ Triggered Rule Frequency</div>', unsafe_allow_html=True)
            abr = stats.get_alerts_by_rule()
            if abr:
                fig, ax = plt.subplots(figsize=(7, 3.8), dpi=120)
                style_axes(fig, ax)
                rules = list(abr.keys())
                counts = list(abr.values())
                bars = ax.bar(rules, counts, color='#f97316', edgecolor='#334155', width=0.5)
                ax.set_ylabel('Alerts Generated', fontsize=8)
                ax.tick_params(axis='x', rotation=25, labelsize=7.5)
                ax.yaxis.set_major_locator(mticker.MaxNLocator(integer=True))
                for bar in bars:
                    height = bar.get_height()
                    if height > 0:
                        ax.annotate(f'{height}',
                                    xy=(bar.get_x() + bar.get_width() / 2, height),
                                    xytext=(0, 3), textcoords="offset points",
                                    ha='center', va='bottom', fontsize=8, color='#f8fafc', fontweight='600')
                fig.tight_layout()
                st.pyplot(fig)
                plt.close(fig)
            else:
                st.caption('No rule firing telemetry available.')

    render_threat_analysis()


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 6: DETECTION RULES
# ══════════════════════════════════════════════════════════════════════════════
elif page == 'Detection Rules':
    st.markdown('''
    <div class="soc-header">
        <div>
            <h2 style="margin: 0; color: #f8fafc; font-size: 1.45rem; font-weight: 700;">Detection Rule Engine Specifications</h2>
            <div style="color: #94a3b8; font-size: 0.82rem; margin-top: 4px;">Active correlation rules, threshold triggers, and detection logic</div>
        </div>
    </div>
    ''', unsafe_allow_html=True)

    thresholds = get_thresholds()
    rules = get_all_rules()

    for rule in rules:
        with st.expander(f"🔹 {rule.rule_id} — {rule.rule_name}  [{rule.severity}]", expanded=False):
            rc1, rc2 = st.columns([2, 1])
            with rc1:
                st.markdown(f"**Description:** {rule.description}")
                st.markdown(f"**Detection Logic:** `{rule.detection_logic}`")
                st.markdown(f"**Evidence Formatting Template:**")
                st.code(rule.evidence_template, language='python')
            with rc2:
                st.markdown(f"**Severity:** {severity_badge(rule.severity)}", unsafe_allow_html=True)
                st.markdown('**Active Threshold Parameters:**')
                if rule.rule_id == 'RULE_001':
                    st.write(f"- Trigger Count: `{thresholds['failed_login_threshold']} failed logins`")
                    st.write(f"- Correlation Window: `{thresholds['failed_login_window']}s`")
                elif rule.rule_id == 'RULE_002':
                    st.write(f"- Unique Usernames: `{thresholds['account_enum_threshold']} distinct accounts`")
                    st.write(f"- Correlation Window: `{thresholds['account_enum_window']}s`")
                elif rule.rule_id == 'RULE_003':
                    st.write(f"- Preceding Failures: `{thresholds['suspicious_login_failures_before_success']} attempts`")
                    st.write(f"- Correlation Window: `{thresholds['suspicious_login_window']}s`")
                elif rule.rule_id == 'RULE_004':
                    st.write(f"- Preceding Failures: `{thresholds['privilege_escalation_min_failures']} attempts`")
                    st.write(f"- Escalation Window: `{thresholds['privilege_escalation_window']}s`")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 7: LOG INGESTION
# ══════════════════════════════════════════════════════════════════════════════
elif page == 'Log Ingestion':
    st.markdown('''
    <div class="soc-header">
        <div>
            <h2 style="margin: 0; color: #f8fafc; font-size: 1.45rem; font-weight: 700;">Telemetry Ingestion Pipeline</h2>
            <div style="color: #94a3b8; font-size: 0.82rem; margin-top: 4px;">Ingest raw log streams, parse, normalize, and execute real-time detection</div>
        </div>
    </div>
    ''', unsafe_allow_html=True)

    tab_demo, tab_upload = st.tabs(['⚡ Live Attack Simulator (Demo Mode)', '📂 Custom Log File Ingestion'])

    with tab_demo:
        st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-bottom:4px;">Simulate Attack Scenarios</div>', unsafe_allow_html=True)
        st.caption('Generate synthetic attacks and push them through the real parsing $\\to$ normalization $\\to$ detection $\\to$ alert pipeline.')

        scenario = st.selectbox(
            'Select Attack Scenario',
            ['Mixed Attack (Recommended)', 'Brute Force (RULE_001)', 'Account Enumeration (RULE_002)',
             'Suspicious Login Sequence (RULE_003)', 'Normal Baseline Traffic'],
        )

        if st.button('🚀 Launch Simulation & Run Pipeline'):
            with st.spinner('Generating telemetry and executing detection rules...'):
                gen = SampleLogGenerator()

                if scenario == 'Normal Baseline Traffic':
                    lines = gen.generate_normal(count=50)
                elif scenario == 'Brute Force (RULE_001)':
                    lines = gen.generate_brute_force(count=10, source_ip='10.0.0.50', target_user='admin')
                elif scenario == 'Account Enumeration (RULE_002)':
                    lines = gen.generate_account_enumeration(source_ip='10.0.0.100')
                elif scenario == 'Suspicious Login Sequence (RULE_003)':
                    lines = gen.generate_suspicious_login(source_ip='10.0.0.75', username='admin')
                else:
                    lines = gen.generate_mixed(count=100)

                filename = f"sim_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
                filepath = gen.save_to_file(lines, filename)

                result = run_pipeline(lines, parser_name='Linux Auth')

                st.success(f'Scenario "{scenario}" completed successfully!')
                st.caption(f'Log saved to: `{filepath}`')

                rc1, rc2, rc3, rc4 = st.columns(4)
                rc1.metric('Lines Processed', result['lines_processed'])
                rc2.metric('Events Normalized', result['events_stored'])
                rc3.metric('Alerts Triggered', result['alerts_generated'])
                rc4.metric('Parsing Errors', result['errors'])

                if result['new_alert_ids']:
                    st.markdown('**Incidents Generated:**')
                    for aid in set(result['new_alert_ids']):
                        st.markdown(f"- `{aid}`")

    with tab_upload:
        st.markdown('<div style="font-size:0.95rem; font-weight:600; color:#f1f5f9; margin-bottom:4px;">Upload Real Telemetry Files</div>', unsafe_allow_html=True)
        uploaded = st.file_uploader(
            'Upload security log file', type=['log', 'txt', 'csv'],
            help='Accepts Linux auth logs, syslog, or Windows Security Event CSVs.'
        )
        parser_choice = st.selectbox('Log Schema Format', list(PARSERS.keys()))

        if uploaded and st.button('Ingest & Analyze File'):
            with st.spinner('Ingesting file...'):
                content = uploaded.read().decode('utf-8', errors='replace')
                lines = content.splitlines()

                result = run_pipeline(lines, parser_name=parser_choice)

                st.success('File ingestion and detection pipeline completed!')
                rc1, rc2, rc3, rc4 = st.columns(4)
                rc1.metric('Lines Processed', result['lines_processed'])
                rc2.metric('Events Stored', result['events_stored'])
                rc3.metric('Alerts Triggered', result['alerts_generated'])
                rc4.metric('Errors', result['errors'])


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 8: REPORTS
# ══════════════════════════════════════════════════════════════════════════════
elif page == 'Reports':
    st.markdown('''
    <div class="soc-header">
        <div>
            <h2 style="margin: 0; color: #f8fafc; font-size: 1.45rem; font-weight: 700;">Executive Reports & Data Export</h2>
            <div style="color: #94a3b8; font-size: 0.82rem; margin-top: 4px;">Download compliance CSV exports and summary audit metrics</div>
        </div>
    </div>
    ''', unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        st.markdown('### 📄 Normalized Events Export')
        try:
            events_data = repo.get_events(limit=10000)
            if events_data:
                df_events = pd.DataFrame(events_data)
                csv_events = df_events.to_csv(index=False).encode('utf-8')
                st.download_button(
                    '📥 Download Events CSV',
                    csv_events,
                    file_name=f"siem_events_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime='text/csv',
                )
                st.caption(f'**{len(events_data)}** records available for CSV export.')
            else:
                st.caption('No events stored in SQLite.')
        except Exception:
            st.caption('No events available.')

    with col2:
        st.markdown('### 🚨 Security Alerts Export')
        try:
            alerts_data = repo.get_alerts(limit=10000)
            if alerts_data:
                df_alerts = pd.DataFrame(alerts_data)
                csv_alerts = df_alerts.to_csv(index=False).encode('utf-8')
                st.download_button(
                    '📥 Download Alerts CSV',
                    csv_alerts,
                    file_name=f"siem_alerts_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime='text/csv',
                )
                st.caption(f'**{len(alerts_data)}** alerts available for CSV export.')
            else:
                st.caption('No alerts stored in SQLite.')
        except Exception:
            st.caption('No alerts available.')

    st.markdown('---')
    st.markdown('### 📊 High-Level Metrics Summary')
    try:
        overview = stats.get_overview()
        summary_data = {
            'Metric Category': [
                'Total Security Events', 'Total Incident Alerts', 'Active / Unresolved Alerts',
                'Critical Severity Alerts', 'High Severity Alerts', 'Medium Severity Alerts',
                'Failed Authentication Events', 'Successful Authentications',
                'Distinct Attacking IPs', 'Distinct Target Accounts',
            ],
            'Value': [
                overview['total_events'], overview['total_alerts'],
                overview.get('active_alerts', 0),
                overview['critical_alerts'], overview['high_alerts'],
                overview['medium_alerts'], overview['failed_logins'],
                overview['successful_logins'], overview['unique_ips'],
                overview['unique_usernames'],
            ],
        }
        st.dataframe(pd.DataFrame(summary_data), use_container_width=True, hide_index=True)
    except Exception:
        st.caption('No summary telemetry available.')


# ══════════════════════════════════════════════════════════════════════════════
# PAGE 9: SETTINGS
# ══════════════════════════════════════════════════════════════════════════════
elif page == 'Settings':
    st.markdown('''
    <div class="soc-header">
        <div>
            <h2 style="margin: 0; color: #f8fafc; font-size: 1.45rem; font-weight: 700;">System Settings & Diagnostics</h2>
            <div style="color: #94a3b8; font-size: 0.82rem; margin-top: 4px;">Dynamic threshold tuning, environment parameters, and database health</div>
        </div>
    </div>
    ''', unsafe_allow_html=True)

    thresholds = get_thresholds()

    st.markdown('### ⚙️ Detection Threshold Configuration')
    sc1, sc2 = st.columns(2)
    with sc1:
        new_fl = st.number_input(
            'Failed Login Threshold (RULE_001)', min_value=1, max_value=100,
            value=thresholds['failed_login_threshold'],
            help='Count of failures from one IP before triggering brute-force alert.'
        )
        new_ae = st.number_input(
            'Account Enumeration Threshold (RULE_002)', min_value=2, max_value=50,
            value=thresholds['account_enum_threshold'],
            help='Unique target usernames tried from one IP before triggering enumeration alert.'
        )
        new_sf = st.number_input(
            'Suspicious Login Failures (RULE_003)', min_value=2, max_value=20,
            value=thresholds['suspicious_login_failures_before_success'],
        )

    with sc2:
        new_fw = st.number_input(
            'Brute Force Window in Seconds (RULE_001)', min_value=30, max_value=3600,
            value=thresholds['failed_login_window'],
        )
        new_aw = st.number_input(
            'Account Enumeration Window in Seconds (RULE_002)', min_value=30, max_value=3600,
            value=thresholds['account_enum_window'],
        )
        new_sw = st.number_input(
            'Suspicious Login Window in Seconds (RULE_003)', min_value=30, max_value=3600,
            value=thresholds['suspicious_login_window'],
        )

    if st.button('💾 Save Threshold Settings'):
        update_threshold('failed_login_threshold', new_fl)
        update_threshold('account_enum_threshold', new_ae)
        update_threshold('suspicious_login_failures_before_success', new_sf)
        update_threshold('failed_login_window', new_fw)
        update_threshold('account_enum_window', new_aw)
        update_threshold('suspicious_login_window', new_sw)
        st.success('Thresholds updated and active across detection engine.')

    st.markdown('---')
    st.markdown('### 🗄️ Database & Storage Diagnostics')
    st.write(f"**Database Path:** `{DB_PATH}`")
    try:
        overview = stats.get_overview()
        st.write(f"- Indexed Events Count: **{overview['total_events']}**")
        st.write(f"- Indexed Alerts Count: **{overview['total_alerts']}**")
    except Exception:
        st.write('Database initializing...')
