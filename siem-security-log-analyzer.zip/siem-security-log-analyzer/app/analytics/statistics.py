"""
Security Statistics - analytics layer that queries real SQLite data
through the repository for dashboard metrics and charts.
"""
from typing import Dict, Any, List

from app.database.repository import Repository


class SecurityStatistics:
    """Computes security analytics from the SQLite database."""

    def __init__(self, repository: Repository):
        self.repo = repository

    def get_overview(self) -> Dict[str, Any]:
        """Get high-level overview metrics for the dashboard."""
        event_stats = self.repo.get_event_stats()
        alert_stats = self.repo.get_alert_stats()

        severity_counts = alert_stats.get('by_severity', {})

        return {
            'total_events': event_stats.get('total_events', 0),
            'total_alerts': alert_stats.get('total_alerts', 0),
            'active_alerts': alert_stats.get('active_alerts', 0),
            'critical_alerts': severity_counts.get('CRITICAL', 0),
            'high_alerts': severity_counts.get('HIGH', 0),
            'medium_alerts': severity_counts.get('MEDIUM', 0),
            'low_alerts': severity_counts.get('LOW', 0),
            'failed_logins': self.repo.get_failed_login_count(),
            'successful_logins': self.repo.get_successful_login_count(),
            'unique_ips': self.repo.get_unique_source_ips(),
            'unique_usernames': self.repo.get_unique_usernames(),
        }

    def get_alerts_by_severity(self) -> Dict[str, int]:
        """Get alert counts grouped by severity."""
        stats = self.repo.get_alert_stats()
        return stats.get('by_severity', {})

    def get_alerts_by_rule(self) -> Dict[str, int]:
        """Get alert counts grouped by rule_name."""
        with self.repo.db.get_connection() as conn:
            cursor = conn.execute(
                "SELECT rule_name, COUNT(*) as cnt "
                "FROM alerts GROUP BY rule_name ORDER BY cnt DESC"
            )
            return {row[0]: row[1] for row in cursor.fetchall()}

    def get_events_over_time(
        self, group_by: str = 'hour', limit: int = 24
    ) -> List[Dict[str, Any]]:
        """Get event counts over time for charting."""
        return self.repo.get_events_over_time(group_by=group_by, limit=limit)

    def get_event_type_distribution(self) -> List[Dict[str, Any]]:
        """Get event counts by type."""
        return self.repo.get_events_by_type()

    def get_auth_distribution(self) -> Dict[str, int]:
        """Get authentication success/failure counts."""
        return self.repo.get_auth_success_failure()

    def get_top_suspicious_ips(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get IPs with the most LOGIN_FAILURE events."""
        with self.repo.db.get_connection() as conn:
            cursor = conn.execute(
                "SELECT source_ip, COUNT(*) as cnt "
                "FROM events "
                "WHERE event_type IN ('LOGIN_FAILURE', 'INVALID_USER') "
                "AND source_ip IS NOT NULL "
                "GROUP BY source_ip ORDER BY cnt DESC LIMIT ?",
                (limit,)
            )
            return [{'ip': row[0], 'count': row[1]} for row in cursor.fetchall()]

    def get_alerts_over_time(
        self, group_by: str = 'hour', limit: int = 24
    ) -> List[Dict[str, Any]]:
        """Get alert counts over time for charting."""
        if group_by == 'hour':
            substr_len = 13
        elif group_by == 'day':
            substr_len = 10
        else:
            substr_len = 16

        with self.repo.db.get_connection() as conn:
            cursor = conn.execute(
                f"SELECT substr(timestamp, 1, {substr_len}) as time_bucket, "
                f"COUNT(*) as cnt FROM alerts "
                f"GROUP BY time_bucket ORDER BY time_bucket DESC LIMIT ?",
                (limit,)
            )
            results = [
                {'time': row[0], 'count': row[1]}
                for row in cursor.fetchall()
            ]
            return results[::-1]

    def get_suspicious_source_ips(self) -> List[str]:
        """Get list of source IPs that appear in alerts."""
        with self.repo.db.get_connection() as conn:
            cursor = conn.execute(
                "SELECT DISTINCT source_ip FROM alerts "
                "WHERE source_ip IS NOT NULL AND source_ip != ''"
            )
            return [row[0] for row in cursor.fetchall()]
