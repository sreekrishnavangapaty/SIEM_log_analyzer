"""
Trend Analyzer - provides threat summaries, attack timelines,
and user activity analysis from the SQLite database.
"""
from typing import Dict, Any, List

from app.database.repository import Repository


class TrendAnalyzer:
    """Analyzes trends and patterns from security event data."""

    def __init__(self, repository: Repository):
        self.repo = repository

    def get_threat_summary(self) -> Dict[str, Any]:
        """Get a summary of threat types and their proportions."""
        alerts = self.repo.get_alerts(limit=1000)
        total = len(alerts)
        if total == 0:
            return {
                'total_threats': 0,
                'by_rule': {},
                'by_severity': {},
            }

        by_rule: Dict[str, int] = {}
        by_severity: Dict[str, int] = {}

        for alert in alerts:
            rule = alert.get('rule_name', 'UNKNOWN')
            sev = alert.get('severity', 'LOW')
            by_rule[rule] = by_rule.get(rule, 0) + 1
            by_severity[sev] = by_severity.get(sev, 0) + 1

        return {
            'total_threats': total,
            'by_rule': by_rule,
            'by_severity': by_severity,
        }

    def get_attack_timeline(self, source_ip: str) -> List[Dict[str, Any]]:
        """Get chronological events for a specific source IP."""
        return self.repo.get_events_for_alert(source_ip=source_ip)

    def get_user_activity(self, username: str) -> Dict[str, Any]:
        """Get activity summary for a specific user."""
        events = self.repo.get_events_for_alert(username=username)

        if not events:
            return {
                'username': username,
                'total_events': 0,
                'event_types': {},
                'source_ips': [],
                'first_seen': None,
                'last_seen': None,
            }

        event_types: Dict[str, int] = {}
        source_ips = set()
        timestamps = []

        for ev in events:
            et = ev.get('event_type', 'UNKNOWN')
            event_types[et] = event_types.get(et, 0) + 1
            if ev.get('source_ip'):
                source_ips.add(ev['source_ip'])
            if ev.get('timestamp'):
                timestamps.append(ev['timestamp'])

        timestamps.sort()

        return {
            'username': username,
            'total_events': len(events),
            'event_types': event_types,
            'source_ips': sorted(source_ips),
            'first_seen': timestamps[0] if timestamps else None,
            'last_seen': timestamps[-1] if timestamps else None,
        }
