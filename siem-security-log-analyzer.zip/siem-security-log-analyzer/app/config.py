import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Base directories
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("DATA_DIR", "data/"))

# Ensure data directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
(DATA_DIR / "processed").mkdir(parents=True, exist_ok=True)
(DATA_DIR / "sample_logs").mkdir(parents=True, exist_ok=True)

# Database configuration
DB_PATH = os.getenv("DB_PATH", str(DATA_DIR / "siem.db"))

# Application configuration
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
DEMO_MODE = os.getenv("DEMO_MODE", "True").lower() in ("true", "1", "yes")

# Detection thresholds and parameters
FAILED_LOGIN_THRESHOLD = int(os.getenv("FAILED_LOGIN_THRESHOLD", 5))
FAILED_LOGIN_WINDOW = int(os.getenv("FAILED_LOGIN_WINDOW", 300))  # seconds
MULTIPLE_USER_THRESHOLD = int(os.getenv("MULTIPLE_USER_THRESHOLD", 3))
CORRELATION_WINDOW = int(os.getenv("CORRELATION_WINDOW", 300))  # seconds
