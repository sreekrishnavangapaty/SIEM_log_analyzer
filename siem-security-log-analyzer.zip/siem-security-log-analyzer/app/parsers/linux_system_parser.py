import re
import logging
from typing import Optional, Dict, Any
from app.parsers.base_parser import BaseParser

logger = logging.getLogger(__name__)

class LinuxSystemParser(BaseParser):
    @property
    def parser_name(self) -> str:
        return "linux_system"
        
    def __init__(self):
        self.syslog_base_pattern = re.compile(
            r'^(?P<timestamp>[A-Z][a-z]{2}\s+\d+\s+\d{2}:\d{2}:\d{2})\s+'
            r'(?P<hostname>\S+)\s+'
            r'(?P<process>[^:]+):\s+'
            r'(?P<message>.*)$'
        )
        
        self.patterns = [
            (re.compile(r'Start(?:ed|ing)\s+(?P<service>.*)'), 'SERVICE_START'),
            (re.compile(r'Stop(?:ped|ping)\s+(?P<service>.*)'), 'SERVICE_STOP'),
            (re.compile(r'(?i)warning'), 'SYSTEM_WARNING'),
            (re.compile(r'(?i)error'), 'SYSTEM_WARNING'),
            (re.compile(r'(?i)permission denied'), 'SUSPICIOUS_ACCESS'),
        ]

    def parse_line(self, raw_line: str) -> Optional[Dict[str, Any]]:
        try:
            base_match = self.syslog_base_pattern.match(raw_line)
            if not base_match:
                return None
                
            parsed = base_match.groupdict()
            msg = parsed['message']
            
            proc_match = re.match(r'^([^\[:]+)', parsed['process'])
            if proc_match:
                parsed['process_name'] = proc_match.group(1)
            else:
                parsed['process_name'] = parsed['process']
                
            parsed['event_type'] = 'UNKNOWN'
            
            for pattern, event_type in self.patterns:
                match = pattern.search(msg)
                if match:
                    parsed['event_type'] = event_type
                    if 'service' in match.groupdict():
                        parsed['message'] = match.group('service')
                    break
                    
            return parsed
        except Exception as e:
            logger.warning(f"Error parsing system line: {e}")
            return None

    def can_parse(self, raw_line: str) -> bool:
        return bool(self.syslog_base_pattern.match(raw_line))
