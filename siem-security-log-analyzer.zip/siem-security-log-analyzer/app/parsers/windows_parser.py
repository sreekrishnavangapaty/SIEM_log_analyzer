import csv
import io
import logging
from typing import Optional, Dict, Any
from app.parsers.base_parser import BaseParser

logger = logging.getLogger(__name__)

class WindowsSecurityParser(BaseParser):
    @property
    def parser_name(self) -> str:
        return "windows_security"
        
    def __init__(self):
        self.event_map = {
            '4624': 'LOGIN_SUCCESS',
            '4625': 'LOGIN_FAILURE',
            '4634': 'LOGOUT',
            '4672': 'PRIVILEGE_CHANGE',
            '4720': 'UNKNOWN'
        }

    def parse_line(self, raw_line: str) -> Optional[Dict[str, Any]]:
        try:
            if raw_line.startswith('Timestamp,EventID'):
                return None
                
            reader = csv.reader(io.StringIO(raw_line))
            row = next(reader)
            
            if len(row) < 7:
                return None
                
            timestamp, event_id, event_type_str, username, source_ip, computer_name, message = row[:7]
            
            event_type = self.event_map.get(event_id, 'UNKNOWN')
            
            parsed = {
                'timestamp': timestamp,
                'hostname': computer_name,
                'username': username,
                'source_ip': source_ip,
                'message': message,
                'event_type': event_type
            }
            return parsed
        except Exception as e:
            logger.warning(f"Error parsing windows line: {e}")
            return None

    def can_parse(self, raw_line: str) -> bool:
        return 'Timestamp,EventID' in raw_line or len(raw_line.split(',')) >= 7
