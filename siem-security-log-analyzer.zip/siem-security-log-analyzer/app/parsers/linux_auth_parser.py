import re
import logging
from typing import Optional, Dict, Any
from app.parsers.base_parser import BaseParser

logger = logging.getLogger(__name__)

class LinuxAuthParser(BaseParser):
    @property
    def parser_name(self) -> str:
        return "linux_auth"
        
    def __init__(self):
        self.syslog_base_pattern = re.compile(
            r'^(?P<timestamp>[A-Z][a-z]{2}\s+\d+\s+\d{2}:\d{2}:\d{2})\s+'
            r'(?P<hostname>\S+)\s+'
            r'(?P<process>[^:]+):\s+'
            r'(?P<message>.*)$'
        )
        
        self.patterns = [
            (re.compile(r'Failed password for (?:invalid user )?(?P<username>\S+) from (?P<source_ip>\S+)'), 'LOGIN_FAILURE'),
            (re.compile(r'Accepted password for (?P<username>\S+) from (?P<source_ip>\S+)'), 'LOGIN_SUCCESS'),
            (re.compile(r'Invalid user (?P<username>\S+) from (?P<source_ip>\S+)'), 'INVALID_USER'),
            (re.compile(r'authentication failure;.*rhost=(?P<source_ip>\S+)(?:\s+user=(?P<username>\S+))?'), 'LOGIN_FAILURE'),
            (re.compile(r'session opened for user (?P<username>\S+)'), 'LOGIN_SUCCESS'),
            (re.compile(r'session closed for user (?P<username>\S+)'), 'LOGOUT'),
            (re.compile(r'(?:sudo:\s+)?(?P<username>\S+)\s+:.*COMMAND='), 'PRIVILEGE_CHANGE')
        ]

    def parse_line(self, raw_line: str) -> Optional[Dict[str, Any]]:
        try:
            base_match = self.syslog_base_pattern.match(raw_line)
            if not base_match:
                return None
                
            parsed = base_match.groupdict()
            msg = parsed['message']
            
            proc_match = re.match(r'^([^\[:]+)', parsed['process'])
            if proc_match:
                parsed['process_name'] = proc_match.group(1)
            else:
                parsed['process_name'] = parsed['process']
                
            parsed['event_type'] = 'UNKNOWN'
            
            for pattern, event_type in self.patterns:
                match = pattern.search(msg)
                if match:
                    parsed['event_type'] = event_type
                    parsed.update(match.groupdict())
                    break
                    
            return parsed
        except Exception as e:
            logger.warning(f"Error parsing auth line: {e}")
            return None

    def can_parse(self, raw_line: str) -> bool:
        return bool(self.syslog_base_pattern.match(raw_line))
