"""
Event Normalizer - transforms raw parsed dict output from any parser
into a normalized SecurityEvent dict matching the events table schema.
"""
import uuid
from datetime import datetime
from typing import Dict, Any, Optional

SEVERITY_MAP = {
    'LOGIN_FAILURE': 'MEDIUM',
    'INVALID_USER': 'MEDIUM',
    'LOGIN_SUCCESS': 'LOW',
    'LOGOUT': 'LOW',
    'PRIVILEGE_CHANGE': 'HIGH',
    'SUSPICIOUS_ACCESS': 'HIGH',
    'SERVICE_START': 'LOW',
    'SERVICE_STOP': 'LOW',
    'SYSTEM_WARNING': 'MEDIUM',
    'UNKNOWN': 'LOW',
}


def _normalize_timestamp(raw_ts: str) -> str:
    """Convert syslog timestamp (e.g. 'Oct  3 14:30:00') to ISO 8601.
    If already ISO-like, return as-is."""
    if not raw_ts:
        return datetime.utcnow().isoformat()

    # Already ISO format
    if 'T' in raw_ts or '-' in raw_ts[:10]:
        return raw_ts

    # Syslog format: 'Oct  3 14:30:00'
    try:
        year = datetime.now().year
        dt = datetime.strptime(f"{year} {raw_ts}", "%Y %b %d %H:%M:%S")
        return dt.isoformat()
    except ValueError:
        try:
            # Try with double space: 'Oct  3 14:30:00'
            year = datetime.now().year
            cleaned = ' '.join(raw_ts.split())
            dt = datetime.strptime(f"{year} {cleaned}", "%Y %b %d %H:%M:%S")
            return dt.isoformat()
        except ValueError:
            return raw_ts


def normalize_event(parsed: Dict[str, Any], parser_name: str,
                    raw_line: str) -> Optional[Dict[str, Any]]:
    """Normalize a parsed event dict into the standard events table schema.

    Args:
        parsed: Dict from a parser's parse_line() method
        parser_name: Name of the parser that produced the dict
        raw_line: The original raw log line

    Returns:
        Normalized event dict matching the events table schema, or None
    """
    if not parsed:
        return None

    event_type = parsed.get('event_type', 'UNKNOWN')
    severity = parsed.get('severity') or SEVERITY_MAP.get(event_type, 'LOW')

    normalized = {
        'id': str(uuid.uuid4()),
        'timestamp': _normalize_timestamp(parsed.get('timestamp', '')),
        'source': parser_name,
        'event_type': event_type,
        'username': parsed.get('username'),
        'source_ip': parsed.get('source_ip'),
        'destination_ip': parsed.get('destination_ip'),
        'hostname': parsed.get('hostname'),
        'process_name': parsed.get('process_name'),
        'severity': severity,
        'message': parsed.get('message', ''),
        'raw_log': raw_line,
        'created_at': datetime.utcnow().isoformat(),
    }

    return normalized
