from abc import ABC, abstractmethod
from typing import Optional, Dict, Any

class BaseParser(ABC):
    @property
    @abstractmethod
    def parser_name(self) -> str:
        pass

    @abstractmethod
    def parse_line(self, raw_line: str) -> Optional[Dict[str, Any]]:
        pass
        
    @abstractmethod
    def can_parse(self, raw_line: str) -> bool:
        pass
