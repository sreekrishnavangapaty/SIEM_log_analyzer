import logging
import sys
from pathlib import Path
from app.config import LOG_LEVEL, DATA_DIR

def setup_logger(name: str) -> logging.Logger:
    """Sets up a logger with console and file handlers."""
    logger = logging.getLogger(name)
    
    # Avoid duplicating handlers
    if logger.handlers:
        return logger
        
    logger.setLevel(getattr(logging, LOG_LEVEL))

    # Formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    # Console Handler
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(getattr(logging, LOG_LEVEL))
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # File Handler
    log_dir = Path(DATA_DIR) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    
    fh = logging.FileHandler(log_dir / "siem.log")
    fh.setLevel(getattr(logging, LOG_LEVEL))
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    return logger
