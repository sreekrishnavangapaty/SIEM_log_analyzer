from datetime import datetime
import re
from typing import Optional
from dateutil import parser

def parse_timestamp(ts_string: str) -> Optional[datetime]:
    """Safely parse a timestamp string into a datetime object."""
    try:
        if not ts_string:
            return None
        return parser.parse(ts_string)
    except (ValueError, TypeError):
        return None

def is_valid_ip(ip_string: str) -> bool:
    """Validates if a string is a valid IPv4 address."""
    if not ip_string:
        return False
    pattern = re.compile(
        r'^((25[0-5]|(2[0-4]|1\d|[1-9]|)\d)\.?\b){4}$'
    )
    return bool(pattern.match(ip_string))

def sanitize_string(s: str) -> str:
    """Basic string sanitization."""
    if not s:
        return ""
    # Remove null bytes and non-printable characters
    s = s.replace('\x00', '')
    return "".join(ch for ch in s if ch.isprintable())
