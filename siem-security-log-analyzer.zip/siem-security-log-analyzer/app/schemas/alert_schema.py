from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional

class AlertStatus(Enum):
    NEW = "NEW"
    INVESTIGATING = "INVESTIGATING"
    RESOLVED = "RESOLVED"
    FALSE_POSITIVE = "FALSE_POSITIVE"

@dataclass
class Alert:
    id: Optional[str]
    alert_id: str
    timestamp: datetime
    rule_id: str
    rule_name: str
    severity: str
    source_ip: Optional[str]
    username: Optional[str]
    event_type: str
    description: str
    evidence: str
    occurrence_count: int
    status: AlertStatus
    first_seen: datetime
    last_seen: datetime

    def to_dict(self):
        return {
            "id": self.id,
            "alert_id": self.alert_id,
            "timestamp": self.timestamp.isoformat() if isinstance(self.timestamp, datetime) else self.timestamp,
            "rule_id": self.rule_id,
            "rule_name": self.rule_name,
            "severity": self.severity,
            "source_ip": self.source_ip,
            "username": self.username,
            "event_type": self.event_type,
            "description": self.description,
            "evidence": self.evidence,
            "occurrence_count": self.occurrence_count,
            "status": self.status.value if isinstance(self.status, AlertStatus) else self.status,
            "first_seen": self.first_seen.isoformat() if isinstance(self.first_seen, datetime) else self.first_seen,
            "last_seen": self.last_seen.isoformat() if isinstance(self.last_seen, datetime) else self.last_seen
        }
