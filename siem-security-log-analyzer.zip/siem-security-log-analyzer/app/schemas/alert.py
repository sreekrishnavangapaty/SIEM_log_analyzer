"""
Alert Schema - security alert data model.
"""
from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class SecurityAlert:
    """Security alert matching the alerts table schema."""
    id: str
    alert_id: str
    timestamp: str
    rule_id: str
    rule_name: str
    severity: str
    source_ip: Optional[str] = None
    username: Optional[str] = None
    event_type: Optional[str] = None
    description: str = ""
    evidence: str = ""
    occurrence_count: int = 1
    status: str = "NEW"
    first_seen: str = ""
    last_seen: str = ""

    def to_dict(self) -> dict:
        return asdict(self)
