"""
Event Schema - normalized security event data model.
"""
from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class SecurityEvent:
    """Normalized security event matching the events table schema."""
    id: str
    timestamp: str
    source: str
    event_type: str
    username: Optional[str] = None
    source_ip: Optional[str] = None
    destination_ip: Optional[str] = None
    hostname: Optional[str] = None
    process_name: Optional[str] = None
    severity: str = "LOW"
    message: str = ""
    raw_log: str = ""
    created_at: str = ""

    def to_dict(self) -> dict:
        return asdict(self)
