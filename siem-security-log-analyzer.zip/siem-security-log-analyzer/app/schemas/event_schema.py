from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional

class EventType(Enum):
    LOGIN_SUCCESS = "LOGIN_SUCCESS"
    LOGIN_FAILURE = "LOGIN_FAILURE"
    INVALID_USER = "INVALID_USER"
    LOGOUT = "LOGOUT"
    PRIVILEGE_CHANGE = "PRIVILEGE_CHANGE"
    SERVICE_START = "SERVICE_START"
    SERVICE_STOP = "SERVICE_STOP"
    SYSTEM_WARNING = "SYSTEM_WARNING"
    SUSPICIOUS_ACCESS = "SUSPICIOUS_ACCESS"
    UNKNOWN = "UNKNOWN"

class Severity(Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

@dataclass
class Event:
    id: Optional[str]
    timestamp: datetime
    source: str
    event_type: EventType
    username: Optional[str]
    source_ip: Optional[str]
    destination_ip: Optional[str]
    hostname: Optional[str]
    process_name: Optional[str]
    severity: Severity
    message: str
    raw_log: str
    created_at: Optional[datetime] = None

    def to_dict(self):
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat() if isinstance(self.timestamp, datetime) else self.timestamp,
            "source": self.source,
            "event_type": self.event_type.value if isinstance(self.event_type, EventType) else self.event_type,
            "username": self.username,
            "source_ip": self.source_ip,
            "destination_ip": self.destination_ip,
            "hostname": self.hostname,
            "process_name": self.process_name,
            "severity": self.severity.value if isinstance(self.severity, Severity) else self.severity,
            "message": self.message,
            "raw_log": self.raw_log,
            "created_at": self.created_at.isoformat() if isinstance(self.created_at, datetime) else self.created_at
        }
