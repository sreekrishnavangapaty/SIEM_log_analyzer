"""Event normalizer that converts parsed log data into a common event format."""

import uuid
from datetime import datetime
import re
import logging
from typing import Dict, Any, Optional
from app.schemas.event_schema import Event, EventType, Severity

logger = logging.getLogger(__name__)

# Syslog month abbreviations
MONTH_MAP = {
    'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6,
    'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12
}

SYSLOG_TS_PATTERN = re.compile(
    r'^([A-Z][a-z]{2})\s+(\d{1,2})\s+(\d{2}):(\d{2}):(\d{2})$'
)


def parse_syslog_timestamp(ts_string: str) -> Optional[datetime]:
    """Parse a syslog-format timestamp like 'Oct  3 14:22:01' into a datetime.
    
    Syslog timestamps do not include a year, so the current year is assumed.
    """
    if not ts_string:
        return None
    ts_string = ts_string.strip()
    match = SYSLOG_TS_PATTERN.match(ts_string)
    if match:
        month_str, day, hour, minute, second = match.groups()
        month = MONTH_MAP.get(month_str)
        if month is None:
            return None
        year = datetime.now().year
        try:
            return datetime(year, month, int(day), int(hour), int(minute), int(second))
        except ValueError:
            return None
    # Try ISO format
    for fmt in ('%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S.%f'):
        try:
            return datetime.strptime(ts_string, fmt)
        except ValueError:
            continue
    return None


class EventNormalizer:
    """Normalizes parsed log data into a common Event schema."""
    
    def __init__(self):
        self.severity_map = {
            'LOGIN_FAILURE': 'MEDIUM',
            'INVALID_USER': 'MEDIUM',
            'LOGIN_SUCCESS': 'LOW',
            'LOGOUT': 'LOW',
            'PRIVILEGE_CHANGE': 'HIGH',
            'SERVICE_START': 'LOW',
            'SERVICE_STOP': 'LOW',
            'SYSTEM_WARNING': 'MEDIUM',
            'SUSPICIOUS_ACCESS': 'HIGH',
            'UNKNOWN': 'LOW'
        }

    def normalize(self, parsed_data: Dict[str, Any], source: str, raw_log: str) -> Optional[Dict[str, Any]]:
        """Convert a parsed log dict into a normalized event dict.
        
        Args:
            parsed_data: Dictionary from parser with extracted fields.
            source: Source identifier (e.g., 'linux_auth', 'linux_system').
            raw_log: The original raw log line.
            
        Returns:
            Normalized event dictionary ready for database storage, or None on error.
        """
        try:
            event_type = parsed_data.get('event_type', 'UNKNOWN')
            severity = self.severity_map.get(event_type, 'LOW')
            
            # Parse timestamp to ISO format
            raw_ts = parsed_data.get('timestamp', '')
            ts_dt = parse_syslog_timestamp(str(raw_ts)) if raw_ts else None
            if ts_dt is None:
                ts_dt = datetime.now()
            timestamp_iso = ts_dt.isoformat()

            def clean_str(val):
                if val is None:
                    return None
                s = str(val).strip()
                return s if s else None
            
            event_dict = {
                'id': str(uuid.uuid4()),
                'timestamp': timestamp_iso,
                'source': source,
                'event_type': event_type,
                'username': clean_str(parsed_data.get('username')),
                'source_ip': clean_str(parsed_data.get('source_ip')),
                'destination_ip': clean_str(parsed_data.get('destination_ip')),
                'hostname': clean_str(parsed_data.get('hostname')),
                'process_name': clean_str(parsed_data.get('process_name')),
                'severity': severity,
                'message': clean_str(parsed_data.get('message')) or raw_log[:500],
                'raw_log': raw_log,
                'created_at': datetime.utcnow().isoformat()
            }
            return event_dict
        except Exception as e:
            logger.error(f"Error normalizing event: {e}")
            return None
