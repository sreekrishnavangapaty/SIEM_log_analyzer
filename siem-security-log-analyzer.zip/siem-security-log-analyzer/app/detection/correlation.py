"""
Correlation Engine - maintains in-memory state for event correlation
across time windows. Tracks failed logins, unique usernames, and
authentication sequences for detection rule evaluation.
"""
from collections import defaultdict
from datetime import datetime
from typing import Optional, Dict, Any, List

from app.detection.thresholds import get_thresholds


class CorrelationTracker:
    """Tracks events in-memory for correlation-based detection."""

    def __init__(self):
        # {source_ip: [(timestamp_iso, username, event_type), ...]}
        self._failed_logins_by_ip: Dict[str, List[tuple]] = defaultdict(list)
        # {(source_ip, username): [(timestamp_iso, event_type), ...]}
        self._auth_sequence: Dict[tuple, List[tuple]] = defaultdict(list)
        # {source_ip: {username: first_seen_iso}}
        self._usernames_by_ip: Dict[str, Dict[str, str]] = defaultdict(dict)
        # {username: [(timestamp_iso, source_ip, event_type), ...]}
        self._events_by_user: Dict[str, List[tuple]] = defaultdict(list)

    def _parse_ts(self, ts: str) -> datetime:
        """Parse an ISO timestamp string to datetime."""
        try:
            return datetime.fromisoformat(ts)
        except (ValueError, TypeError):
            return datetime.utcnow()

    def _prune(self, entries: list, cutoff: datetime,
               ts_index: int = 0) -> list:
        """Remove entries older than cutoff. ts_index is the position
        of the timestamp string in each tuple."""
        return [
            e for e in entries
            if self._parse_ts(e[ts_index]) >= cutoff
        ]

    def add_event(self, event: Dict[str, Any]) -> None:
        """Add a normalized event to the correlation tracker."""
        etype = event.get('event_type', '')
        src_ip = event.get('source_ip') or ''
        username = event.get('username') or ''
        ts = event.get('timestamp', datetime.utcnow().isoformat())

        thresholds = get_thresholds()

        # Track failed logins by IP
        if etype in ('LOGIN_FAILURE', 'INVALID_USER'):
            self._failed_logins_by_ip[src_ip].append((ts, username, etype))
            if username:
                self._usernames_by_ip[src_ip][username] = ts

        # Track auth sequences by (ip, user)
        if etype in ('LOGIN_FAILURE', 'INVALID_USER', 'LOGIN_SUCCESS'):
            key = (src_ip, username)
            self._auth_sequence[key].append((ts, etype))

        # Track privilege changes by user
        if etype == 'PRIVILEGE_CHANGE':
            self._events_by_user[username].append((ts, src_ip, etype))

        # Periodic cleanup
        self._cleanup_expired()

    def _cleanup_expired(self) -> None:
        """Remove entries outside the maximum possible window."""
        thresholds = get_thresholds()
        max_window = max(
            thresholds['failed_login_window'],
            thresholds['account_enum_window'],
            thresholds['suspicious_login_window'],
            thresholds['privilege_escalation_window'],
        )
        cutoff = datetime.utcnow()
        from datetime import timedelta
        cutoff = cutoff - timedelta(seconds=max_window * 2)

        # Prune failed logins
        for ip in list(self._failed_logins_by_ip.keys()):
            self._failed_logins_by_ip[ip] = self._prune(
                self._failed_logins_by_ip[ip], cutoff, 0
            )
            if not self._failed_logins_by_ip[ip]:
                del self._failed_logins_by_ip[ip]

        # Prune auth sequences
        for key in list(self._auth_sequence.keys()):
            self._auth_sequence[key] = self._prune(
                self._auth_sequence[key], cutoff, 0
            )
            if not self._auth_sequence[key]:
                del self._auth_sequence[key]

    def check_brute_force(self, source_ip: str) -> Optional[Dict[str, Any]]:
        """Check if source_ip has exceeded the brute-force threshold.

        Returns a detection result dict or None.
        """
        if not source_ip or source_ip not in self._failed_logins_by_ip:
            return None

        thresholds = get_thresholds()
        window = thresholds['failed_login_window']
        threshold = thresholds['failed_login_threshold']

        now = datetime.utcnow()
        from datetime import timedelta
        cutoff = now - timedelta(seconds=window)

        entries = [
            e for e in self._failed_logins_by_ip[source_ip]
            if self._parse_ts(e[0]) >= cutoff
        ]

        if len(entries) < threshold:
            return None

        timestamps = [self._parse_ts(e[0]) for e in entries]
        usernames = list({e[1] for e in entries if e[1]})
        primary_user = max(
            set(e[1] for e in entries if e[1]),
            key=lambda u: sum(1 for e in entries if e[1] == u),
            default=''
        )

        return {
            'rule_id': 'RULE_001',
            'source_ip': source_ip,
            'username': primary_user,
            'count': len(entries),
            'first_seen': min(timestamps).isoformat(),
            'last_seen': max(timestamps).isoformat(),
            'usernames': usernames,
            'window': window,
            'threshold': threshold,
        }

    def check_account_enumeration(
        self, source_ip: str
    ) -> Optional[Dict[str, Any]]:
        """Check if source_ip is enumerating accounts.

        Returns a detection result dict or None.
        """
        if not source_ip or source_ip not in self._usernames_by_ip:
            return None

        thresholds = get_thresholds()
        window = thresholds['account_enum_window']
        threshold = thresholds['account_enum_threshold']

        now = datetime.utcnow()
        from datetime import timedelta
        cutoff = now - timedelta(seconds=window)

        # Filter usernames seen within window
        active_users = {
            user: ts
            for user, ts in self._usernames_by_ip[source_ip].items()
            if self._parse_ts(ts) >= cutoff
        }

        if len(active_users) < threshold:
            return None

        timestamps = [self._parse_ts(ts) for ts in active_users.values()]

        return {
            'rule_id': 'RULE_002',
            'source_ip': source_ip,
            'username': ', '.join(sorted(active_users.keys())[:5]),
            'unique_count': len(active_users),
            'usernames': sorted(active_users.keys()),
            'first_seen': min(timestamps).isoformat(),
            'last_seen': max(timestamps).isoformat(),
            'window': window,
            'threshold': threshold,
        }

    def check_suspicious_login(
        self, source_ip: str, username: str
    ) -> Optional[Dict[str, Any]]:
        """Check for fail-fail-...-success pattern.

        Returns a detection result dict or None.
        """
        key = (source_ip, username)
        if key not in self._auth_sequence:
            return None

        thresholds = get_thresholds()
        window = thresholds['suspicious_login_window']
        min_failures = thresholds['suspicious_login_failures_before_success']

        now = datetime.utcnow()
        from datetime import timedelta
        cutoff = now - timedelta(seconds=window)

        entries = [
            e for e in self._auth_sequence[key]
            if self._parse_ts(e[0]) >= cutoff
        ]

        if len(entries) < min_failures + 1:
            return None

        # Check if the last entry is a success and preceded by failures
        if entries[-1][1] != 'LOGIN_SUCCESS':
            return None

        # Count consecutive failures before the success
        failure_count = 0
        for i in range(len(entries) - 2, -1, -1):
            if entries[i][1] in ('LOGIN_FAILURE', 'INVALID_USER'):
                failure_count += 1
            else:
                break

        if failure_count < min_failures:
            return None

        timestamps = [self._parse_ts(e[0]) for e in entries]

        return {
            'rule_id': 'RULE_003',
            'source_ip': source_ip,
            'username': username,
            'failure_count': failure_count,
            'first_seen': min(timestamps).isoformat(),
            'last_seen': max(timestamps).isoformat(),
            'window': window,
        }

    def check_privilege_escalation(
        self, source_ip: str, username: str
    ) -> Optional[Dict[str, Any]]:
        """Check for privilege escalation following failed auth attempts.

        Returns a detection result dict or None.
        """
        if not username:
            return None

        thresholds = get_thresholds()
        window = thresholds['privilege_escalation_window']

        now = datetime.utcnow()
        from datetime import timedelta
        cutoff = now - timedelta(seconds=window)

        # Check if this user had prior failed logins
        failure_count = 0
        first_failure = None

        for ip, entries in self._failed_logins_by_ip.items():
            for ts, user, etype in entries:
                if user == username and self._parse_ts(ts) >= cutoff:
                    failure_count += 1
                    if first_failure is None or ts < first_failure:
                        first_failure = ts
        min_failures = thresholds.get('privilege_escalation_min_failures', 3)
        if failure_count < min_failures:
            return None

        return {
            'rule_id': 'RULE_004',
            'source_ip': source_ip,
            'username': username,
            'failure_count': failure_count,
            'first_seen': first_failure,
            'last_seen': now.isoformat(),
            'window': window,
        }

    def cleanup(self) -> None:
        """Force cleanup of all expired entries."""
        self._cleanup_expired()

    def reset(self) -> None:
        """Reset all tracking state."""
        self._failed_logins_by_ip.clear()
        self._auth_sequence.clear()
        self._usernames_by_ip.clear()
        self._events_by_user.clear()
