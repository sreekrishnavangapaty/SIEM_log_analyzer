"""
Detection Thresholds - centralized configuration for all detection rule thresholds.
Imports from app.config and provides runtime-updateable threshold management.
"""
from app.config import (
    FAILED_LOGIN_THRESHOLD,
    FAILED_LOGIN_WINDOW,
    MULTIPLE_USER_THRESHOLD,
    CORRELATION_WINDOW,
)

# Runtime-mutable thresholds (initialized from config)
_thresholds = {
    'failed_login_threshold': FAILED_LOGIN_THRESHOLD,
    'failed_login_window': FAILED_LOGIN_WINDOW,
    'account_enum_threshold': MULTIPLE_USER_THRESHOLD,
    'account_enum_window': CORRELATION_WINDOW,
    'suspicious_login_failures_before_success': 3,
    'suspicious_login_window': CORRELATION_WINDOW,
    'privilege_escalation_window': 600,
    'privilege_escalation_min_failures': 3,
}


def get_thresholds() -> dict:
    """Return a copy of all current detection thresholds."""
    return dict(_thresholds)


def get_threshold(name: str):
    """Get a single threshold value by name."""
    return _thresholds.get(name)


def update_threshold(name: str, value) -> bool:
    """Update a threshold value at runtime.

    Returns True if the threshold was updated, False if name is unknown.
    """
    if name in _thresholds:
        _thresholds[name] = int(value)
        return True
    return False
