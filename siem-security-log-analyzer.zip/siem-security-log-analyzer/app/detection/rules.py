"""
Detection Rules - definitions for all SIEM detection rules.
Each rule is a dataclass with metadata describing the detection logic.
"""
from dataclasses import dataclass, asdict
from typing import Dict, Optional, List


@dataclass
class DetectionRule:
    """Definition of a single detection rule."""
    rule_id: str
    rule_name: str
    description: str
    severity: str
    detection_logic: str
    evidence_template: str


# ── Rule Definitions ──────────────────────────────────────────────────────────

RULES: Dict[str, DetectionRule] = {
    'RULE_001': DetectionRule(
        rule_id='RULE_001',
        rule_name='BRUTE_FORCE',
        description=(
            'Detects repeated failed authentication attempts from the same '
            'source IP within a configurable time window, indicating a '
            'potential brute-force attack.'
        ),
        severity='HIGH',
        detection_logic=(
            'Count failed login events (LOGIN_FAILURE, INVALID_USER) from '
            'the same source_ip within the configured time window. Trigger '
            'when the count exceeds the failed_login_threshold.'
        ),
        evidence_template=(
            'Source IP {source_ip} generated {count} failed login attempts '
            'within {window} seconds, exceeding the configured threshold '
            'of {threshold}. Target username: {username}. '
            'First seen: {first_seen}. Last seen: {last_seen}.'
        ),
    ),
    'RULE_002': DetectionRule(
        rule_id='RULE_002',
        rule_name='ACCOUNT_ENUMERATION',
        description=(
            'Detects a single source IP attempting authentication against '
            'multiple different usernames within a configurable time window, '
            'indicating potential account enumeration or credential stuffing.'
        ),
        severity='HIGH',
        detection_logic=(
            'Track unique usernames in failed authentication attempts from '
            'the same source_ip. Trigger when the unique username count '
            'exceeds the account_enum_threshold within the time window.'
        ),
        evidence_template=(
            'Source IP {source_ip} attempted authentication against '
            '{unique_count} unique usernames within {window} seconds, '
            'exceeding the configured threshold of {threshold}. '
            'Usernames targeted: {usernames}. '
            'First seen: {first_seen}. Last seen: {last_seen}.'
        ),
    ),
    'RULE_003': DetectionRule(
        rule_id='RULE_003',
        rule_name='SUSPICIOUS_LOGIN_SEQUENCE',
        description=(
            'Detects a suspicious authentication sequence where multiple '
            'failed login attempts are followed by a successful login from '
            'the same source, suggesting a possible compromised credential '
            'after password guessing.'
        ),
        severity='MEDIUM',
        detection_logic=(
            'Track authentication sequences per (source_ip, username). '
            'Trigger when a LOGIN_SUCCESS follows N or more consecutive '
            'LOGIN_FAILURE events within the correlation window.'
        ),
        evidence_template=(
            'Suspicious authentication sequence detected from source IP '
            '{source_ip} for user {username}: {failure_count} failed '
            'attempts followed by a successful login within {window} '
            'seconds. This pattern requires investigation to determine '
            'if the account was compromised. '
            'First failure: {first_seen}. Successful login: {last_seen}.'
        ),
    ),
    'RULE_004': DetectionRule(
        rule_id='RULE_004',
        rule_name='PRIVILEGE_ESCALATION',
        description=(
            'Detects suspicious privilege-related activity (e.g. sudo usage) '
            'following prior failed authentication attempts from the same '
            'source or user, indicating potential privilege escalation after '
            'a compromise.'
        ),
        severity='CRITICAL',
        detection_logic=(
            'Monitor for PRIVILEGE_CHANGE events from users or IPs that '
            'have recent failed authentication history within the '
            'privilege escalation window.'
        ),
        evidence_template=(
            'Privilege escalation activity detected for user {username} '
            'from source IP {source_ip}. This user/source had '
            '{failure_count} failed authentication attempts before '
            'gaining elevated privileges within {window} seconds. '
            'First failure: {first_seen}. Privilege change: {last_seen}.'
        ),
    ),
}


def get_rule(rule_id: str) -> Optional[DetectionRule]:
    """Get a detection rule by its ID."""
    return RULES.get(rule_id)


def get_all_rules() -> List[DetectionRule]:
    """Return all detection rules."""
    return list(RULES.values())


def get_rule_dict(rule_id: str) -> Optional[dict]:
    """Get a detection rule as a dict."""
    rule = RULES.get(rule_id)
    return asdict(rule) if rule else None
