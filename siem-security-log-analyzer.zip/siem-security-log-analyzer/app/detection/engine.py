"""
Detection Engine - orchestrates event processing through all detection rules
using the correlation tracker.
"""
from typing import List, Dict, Any

from app.detection.correlation import CorrelationTracker
from app.detection.rules import get_all_rules, get_rule, RULES
from app.detection.thresholds import get_thresholds


class DetectionEngine:
    """Processes normalized events through detection rules."""

    def __init__(self, correlation: CorrelationTracker = None):
        self.correlation = correlation or CorrelationTracker()

    def process_event(self, event: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Process a normalized event through all detection rules.

        Args:
            event: A normalized event dict from the normalizer.

        Returns:
            List of detection result dicts (may be empty).
        """
        detections = []
        etype = event.get('event_type', '')
        src_ip = event.get('source_ip', '')
        username = event.get('username', '')

        # Add event to correlation tracker first
        self.correlation.add_event(event)

        # Rule 001 & 002: Check on failed login events
        if etype in ('LOGIN_FAILURE', 'INVALID_USER'):
            # Check brute force
            result = self.correlation.check_brute_force(src_ip)
            if result:
                rule = get_rule('RULE_001')
                result['rule_name'] = rule.rule_name
                result['severity'] = rule.severity
                result['event_type'] = etype
                result['description'] = rule.description
                result['evidence'] = rule.evidence_template.format(**result)
                detections.append(result)

            # Check account enumeration
            result = self.correlation.check_account_enumeration(src_ip)
            if result:
                rule = get_rule('RULE_002')
                result['rule_name'] = rule.rule_name
                result['severity'] = rule.severity
                result['event_type'] = etype
                result['description'] = rule.description
                result['evidence'] = rule.evidence_template.format(**result)
                detections.append(result)

        # Rule 003: Check on successful login
        if etype == 'LOGIN_SUCCESS':
            result = self.correlation.check_suspicious_login(src_ip, username)
            if result:
                rule = get_rule('RULE_003')
                result['rule_name'] = rule.rule_name
                result['severity'] = rule.severity
                result['event_type'] = etype
                result['description'] = rule.description
                result['evidence'] = rule.evidence_template.format(**result)
                detections.append(result)

        # Rule 004: Check on privilege change
        if etype == 'PRIVILEGE_CHANGE':
            result = self.correlation.check_privilege_escalation(
                src_ip, username
            )
            if result:
                rule = get_rule('RULE_004')
                result['rule_name'] = rule.rule_name
                result['severity'] = rule.severity
                result['event_type'] = etype
                result['description'] = rule.description
                result['evidence'] = rule.evidence_template.format(**result)
                detections.append(result)

        return detections

    def get_rules(self):
        """Return all detection rule definitions."""
        return get_all_rules()

    def reset(self):
        """Reset the correlation tracker state."""
        self.correlation.reset()
