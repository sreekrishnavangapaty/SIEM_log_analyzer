import os
import logging
from typing import Iterator, Optional

logger = logging.getLogger(__name__)

class LogReader:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.total_lines_read = 0

    def read_lines(self) -> Iterator[str]:
        if not os.path.exists(self.file_path):
            logger.error(f"File not found: {self.file_path}")
            return
            
        try:
            with open(self.file_path, 'r', encoding='utf-8', errors='replace') as f:
                for line in f:
                    self.total_lines_read += 1
                    yield line.rstrip('\n')
        except PermissionError:
            logger.error(f"Permission denied: {self.file_path}")
        except Exception as e:
            logger.error(f"Error reading file {self.file_path}: {e}")
