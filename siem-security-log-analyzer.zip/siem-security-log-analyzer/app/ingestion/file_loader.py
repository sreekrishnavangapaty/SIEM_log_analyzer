import os
import logging
from typing import Dict, Any, Union, IO
from app.ingestion.log_reader import LogReader
from app.parsers.linux_auth_parser import LinuxAuthParser
from app.parsers.linux_system_parser import LinuxSystemParser
from app.parsers.windows_parser import WindowsSecurityParser
from app.normalization.normalizer import EventNormalizer

logger = logging.getLogger(__name__)

class FileLoader:
    def __init__(self):
        self.parsers = {
            'linux_auth': LinuxAuthParser(),
            'linux_system': LinuxSystemParser(),
            'windows_security': WindowsSecurityParser()
        }
        self.normalizer = EventNormalizer()

    def process_file(self, file_path_or_obj: Union[str, IO], log_type: str = None) -> Dict[str, Any]:
        results = {
            'total_lines': 0,
            'parsed_lines': 0,
            'skipped_lines': 0,
            'events': []
        }
        
        parser = None
        if log_type and log_type in self.parsers:
            parser = self.parsers[log_type]
            
        try:
            if isinstance(file_path_or_obj, str):
                if not parser:
                    parser = self._guess_parser(file_path_or_obj)
                    if not parser:
                        logger.error("Could not determine log type.")
                        return results
                        
                reader = LogReader(file_path_or_obj)
                for line in reader.read_lines():
                    self._process_line(line, parser, results)
                results['total_lines'] = reader.total_lines_read
            else:
                if not parser:
                    parser = self.parsers['linux_auth']
                    
                content = file_path_or_obj.read()
                if isinstance(content, bytes):
                    content = content.decode('utf-8', errors='replace')
                lines = content.splitlines()
                results['total_lines'] = len(lines)
                for line in lines:
                    self._process_line(line, parser, results)
                    
        except Exception as e:
            logger.error(f"Error processing file: {e}")
            
        return results

    def _process_line(self, line: str, parser, results: Dict[str, Any]):
        if not line.strip():
            results['skipped_lines'] += 1
            return
            
        if len(line) > 10000:
            line = line[:10000]
            
        parsed_dict = parser.parse_line(line)
        if parsed_dict:
            event = self.normalizer.normalize(parsed_dict, parser.parser_name, line)
            if event:
                results['events'].append(event)
                results['parsed_lines'] += 1
            else:
                results['skipped_lines'] += 1
        else:
            results['skipped_lines'] += 1
            
    def _guess_parser(self, file_path: str):
        basename = os.path.basename(file_path).lower()
        if 'auth' in basename:
            return self.parsers['linux_auth']
        elif 'sys' in basename or 'daemon' in basename:
            return self.parsers['linux_system']
        elif 'win' in basename or 'security' in basename or file_path.endswith('.csv'):
            return self.parsers['windows_security']
        return self.parsers['linux_auth']
