"""
Alert Manager - creates, deduplicates, stores, and manages security alerts.
"""
import uuid
from datetime import datetime
from typing import Optional, Dict, Any

from app.database.repository import Repository
from app.detection.rules import get_rule


VALID_STATUSES = ('NEW', 'INVESTIGATING', 'RESOLVED', 'FALSE_POSITIVE')


class AlertManager:
    """Manages the lifecycle of security alerts."""

    def __init__(self, repository: Repository):
        self.repo = repository
        self._alert_counter = 0

    def _generate_alert_id(self) -> str:
        """Generate a unique human-readable alert ID."""
        self._alert_counter += 1
        date_str = datetime.utcnow().strftime('%Y%m%d')
        return f"ALT-{date_str}-{self._alert_counter:04d}"

    def process_detection(self, detection: Dict[str, Any]) -> Optional[str]:
        """Process a detection result from the engine into an alert.

        Handles deduplication: if an active alert already exists for the
        same rule_id + source_ip, update its occurrence count instead of
        creating a duplicate.

        Args:
            detection: Detection result dict from DetectionEngine.

        Returns:
            The alert_id (new or existing), or None on error.
        """
        try:
            rule_id = detection.get('rule_id', '')
            source_ip = detection.get('source_ip', '')
            username = detection.get('username', '')
            last_seen = detection.get('last_seen', datetime.utcnow().isoformat())

            # Check for existing active alert (deduplication)
            existing = self.repo.find_existing_alert(
                rule_id=rule_id,
                source_ip=source_ip if source_ip else None,
            )

            if existing:
                # Update existing alert
                self.repo.update_alert_occurrence(
                    alert_id=existing['alert_id'],
                    last_seen=last_seen,
                    new_evidence=detection.get('evidence', ''),
                )
                return existing['alert_id']

            # Create new alert
            rule = get_rule(rule_id)
            alert_id = self._generate_alert_id()
            now = datetime.utcnow().isoformat()

            alert_dict = {
                'id': str(uuid.uuid4()),
                'alert_id': alert_id,
                'timestamp': now,
                'rule_id': rule_id,
                'rule_name': rule.rule_name if rule else detection.get('rule_name', 'UNKNOWN'),
                'severity': detection.get('severity', 'MEDIUM'),
                'source_ip': source_ip,
                'username': username,
                'event_type': detection.get('event_type', ''),
                'description': detection.get('description', ''),
                'evidence': detection.get('evidence', ''),
                'occurrence_count': detection.get('count', 1),
                'status': 'NEW',
                'first_seen': detection.get('first_seen', now),
                'last_seen': detection.get('last_seen', now),
            }

            self.repo.insert_alert(alert_dict)
            return alert_id

        except Exception:
            return None

    def update_status(self, alert_id: str, new_status: str) -> bool:
        """Update the status of an alert.

        Args:
            alert_id: The alert_id or primary id.
            new_status: One of NEW, INVESTIGATING, RESOLVED, FALSE_POSITIVE.

        Returns:
            True if the update succeeded.
        """
        if new_status not in VALID_STATUSES:
            return False
        return self.repo.update_alert_status(alert_id, new_status)

    def get_alert_details(self, alert_id: str) -> Optional[Dict[str, Any]]:
        """Get full details for a specific alert."""
        return self.repo.get_alert_by_id(alert_id)
