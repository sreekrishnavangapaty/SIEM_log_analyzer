import sqlite3
import contextlib
from pathlib import Path
import logging
from app.config import DB_PATH
from app.utils.logger import setup_logger

logger = setup_logger(__name__)

class DatabaseConnection:
    """Manages SQLite database connections."""
    
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._ensure_db_directory()
        
    def _ensure_db_directory(self):
        """Ensure the directory for the database exists."""
        db_dir = Path(self.db_path).parent
        db_dir.mkdir(parents=True, exist_ok=True)
        
    @contextlib.contextmanager
    def get_connection(self):
        """Context manager for SQLite connection."""
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            yield conn
        except sqlite3.Error as e:
            logger.error(f"Database connection error: {e}")
            raise
        finally:
            if conn:
                conn.close()
