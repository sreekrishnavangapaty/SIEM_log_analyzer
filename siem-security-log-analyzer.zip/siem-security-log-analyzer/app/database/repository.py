import uuid
from typing import List, Dict, Any, Optional
from datetime import datetime
from app.database.connection import DatabaseConnection
from app.utils.logger import setup_logger

logger = setup_logger(__name__)

class Repository:
    """Data access layer for events and alerts."""
    
    def __init__(self, db_connection: DatabaseConnection):
        self.db = db_connection

    def insert_event(self, event_dict: Dict[str, Any]) -> str:
        """Inserts a new event into the database."""
        event_id = event_dict.get('id') or str(uuid.uuid4())
        
        query = """
        INSERT INTO events (
            id, timestamp, source, event_type, username, source_ip, 
            destination_ip, hostname, process_name, severity, message, 
            raw_log, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        values = (
            event_id,
            event_dict.get('timestamp'),
            event_dict.get('source'),
            event_dict.get('event_type'),
            event_dict.get('username'),
            event_dict.get('source_ip'),
            event_dict.get('destination_ip'),
            event_dict.get('hostname'),
            event_dict.get('process_name'),
            event_dict.get('severity'),
            event_dict.get('message'),
            event_dict.get('raw_log'),
            event_dict.get('created_at', datetime.utcnow().isoformat())
        )
        
        with self.db.get_connection() as conn:
            conn.execute(query, values)
            conn.commit()
            
        return event_id

    def insert_alert(self, alert_dict: Dict[str, Any]) -> str:
        """Inserts a new alert into the database."""
        alert_pk = alert_dict.get('id') or str(uuid.uuid4())
        
        query = """
        INSERT INTO alerts (
            id, alert_id, timestamp, rule_id, rule_name, severity, 
            source_ip, username, event_type, description, evidence, 
            occurrence_count, status, first_seen, last_seen
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        values = (
            alert_pk,
            alert_dict.get('alert_id'),
            alert_dict.get('timestamp'),
            alert_dict.get('rule_id'),
            alert_dict.get('rule_name'),
            alert_dict.get('severity'),
            alert_dict.get('source_ip'),
            alert_dict.get('username'),
            alert_dict.get('event_type'),
            alert_dict.get('description'),
            alert_dict.get('evidence'),
            alert_dict.get('occurrence_count', 1),
            alert_dict.get('status'),
            alert_dict.get('first_seen'),
            alert_dict.get('last_seen')
        )
        
        with self.db.get_connection() as conn:
            conn.execute(query, values)
            conn.commit()
            
        return alert_pk
        
    def get_events(self, limit: int = 100, offset: int = 0, **filters) -> List[Dict[str, Any]]:
        """Retrieves events matching given filters."""
        query = "SELECT * FROM events"
        params = []
        
        if filters:
            conditions = []
            for k, v in filters.items():
                if v is not None:
                    conditions.append(f"{k} = ?")
                    params.append(v)
            if conditions:
                query += " WHERE " + " AND ".join(conditions)
                
        query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        
        with self.db.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_alerts(self, limit: int = 100, offset: int = 0, **filters) -> List[Dict[str, Any]]:
        """Retrieves alerts matching given filters."""
        query = "SELECT * FROM alerts"
        params = []
        
        if filters:
            conditions = []
            for k, v in filters.items():
                if v is not None:
                    conditions.append(f"{k} = ?")
                    params.append(v)
            if conditions:
                query += " WHERE " + " AND ".join(conditions)
                
        query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        
        with self.db.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_alert_by_id(self, alert_id: str) -> Optional[Dict[str, Any]]:
        """Gets a specific alert by its ID."""
        with self.db.get_connection() as conn:
            cursor = conn.execute("SELECT * FROM alerts WHERE id = ? OR alert_id = ?", (alert_id, alert_id))
            row = cursor.fetchone()
            return dict(row) if row else None

    def update_alert_status(self, alert_id: str, status: str) -> bool:
        """Updates the status of an alert."""
        with self.db.get_connection() as conn:
            cursor = conn.execute(
                "UPDATE alerts SET status = ? WHERE id = ? OR alert_id = ?",
                (status, alert_id, alert_id)
            )
            conn.commit()
            return cursor.rowcount > 0

    def update_alert_occurrence(self, alert_id: str, last_seen: str, new_evidence: str = None) -> bool:
        """Updates alert occurrence count and last seen time."""
        query = """
        UPDATE alerts 
        SET occurrence_count = occurrence_count + 1, last_seen = ?
        """
        params = [last_seen]
        
        if new_evidence:
            query += ", evidence = evidence || '\n' || ?"
            params.append(new_evidence)
            
        query += " WHERE alert_id = ?"
        params.append(alert_id)
        
        with self.db.get_connection() as conn:
            cursor = conn.execute(query, params)
            conn.commit()
            return cursor.rowcount > 0

    def find_existing_alert(self, rule_id: str, source_ip: str = None, username: str = None, 
                           time_window_start: str = None) -> Optional[Dict[str, Any]]:
        """Finds an existing active alert for deduplication."""
        query = "SELECT * FROM alerts WHERE rule_id = ? AND status IN ('NEW', 'INVESTIGATING')"
        params = [rule_id]
        
        if source_ip:
            query += " AND source_ip = ?"
            params.append(source_ip)
        if username:
            query += " AND username = ?"
            params.append(username)
        if time_window_start:
            query += " AND last_seen >= ?"
            params.append(time_window_start)
            
        query += " ORDER BY last_seen DESC LIMIT 1"
        
        with self.db.get_connection() as conn:
            cursor = conn.execute(query, params)
            row = cursor.fetchone()
            return dict(row) if row else None

    def get_events_for_alert(self, source_ip: str = None, username: str = None, 
                            start_time: str = None, end_time: str = None) -> List[Dict[str, Any]]:
        """Retrieves related events for alert investigation."""
        query = "SELECT * FROM events WHERE 1=1"
        params = []
        
        if source_ip:
            query += " AND source_ip = ?"
            params.append(source_ip)
        if username:
            query += " AND username = ?"
            params.append(username)
        if start_time:
            query += " AND timestamp >= ?"
            params.append(start_time)
        if end_time:
            query += " AND timestamp <= ?"
            params.append(end_time)
            
        query += " ORDER BY timestamp ASC"
        
        with self.db.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_event_stats(self) -> Dict[str, Any]:
        """Gets high-level event statistics."""
        with self.db.get_connection() as conn:
            total = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            by_type = dict(conn.execute(
                "SELECT event_type, COUNT(*) FROM events GROUP BY event_type"
            ).fetchall())
            by_severity = dict(conn.execute(
                "SELECT severity, COUNT(*) FROM events GROUP BY severity"
            ).fetchall())
            
            return {
                "total_events": total,
                "by_type": by_type,
                "by_severity": by_severity
            }

    def get_alert_stats(self) -> Dict[str, Any]:
        """Gets high-level alert statistics."""
        with self.db.get_connection() as conn:
            total = conn.execute("SELECT COUNT(*) FROM alerts").fetchone()[0]
            active = conn.execute(
                "SELECT COUNT(*) FROM alerts WHERE status IN ('NEW', 'INVESTIGATING')"
            ).fetchone()[0]
            by_severity = dict(conn.execute(
                "SELECT severity, COUNT(*) FROM alerts GROUP BY severity"
            ).fetchall())
            
            return {
                "total_alerts": total,
                "active_alerts": active,
                "by_severity": by_severity
            }

    def get_top_source_ips(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Gets top source IP addresses by event count."""
        query = """
        SELECT source_ip, COUNT(*) as count 
        FROM events 
        WHERE source_ip IS NOT NULL 
        GROUP BY source_ip 
        ORDER BY count DESC LIMIT ?
        """
        with self.db.get_connection() as conn:
            cursor = conn.execute(query, (limit,))
            return [{"ip": row[0], "count": row[1]} for row in cursor.fetchall()]

    def get_events_over_time(self, group_by: str = "hour", limit: int = 24) -> List[Dict[str, Any]]:
        """Gets event counts grouped by time."""
        # Simple implementation, string formatting varies by SQL dialect
        # For SQLite, we can use substr on the ISO format timestamp
        if group_by == "hour":
            substr_len = 13 # YYYY-MM-DDTHH
        elif group_by == "day":
            substr_len = 10 # YYYY-MM-DD
        else:
            substr_len = 16 # YYYY-MM-DDTHH:MM
            
        query = f"""
        SELECT substr(timestamp, 1, {substr_len}) as time_bucket, COUNT(*) as count 
        FROM events 
        GROUP BY time_bucket 
        ORDER BY time_bucket DESC LIMIT ?
        """
        with self.db.get_connection() as conn:
            cursor = conn.execute(query, (limit,))
            # Reverse to get chronological order for charting
            results = [{"time": row[0], "count": row[1]} for row in cursor.fetchall()]
            return results[::-1]

    def get_events_by_type(self) -> List[Dict[str, Any]]:
        """Gets event counts grouped by type."""
        query = "SELECT event_type, COUNT(*) as count FROM events GROUP BY event_type ORDER BY count DESC"
        with self.db.get_connection() as conn:
            cursor = conn.execute(query)
            return [{"type": row[0], "count": row[1]} for row in cursor.fetchall()]

    def get_auth_success_failure(self) -> Dict[str, int]:
        """Gets counts of successful and failed logins."""
        with self.db.get_connection() as conn:
            success = conn.execute(
                "SELECT COUNT(*) FROM events WHERE event_type = 'LOGIN_SUCCESS'"
            ).fetchone()[0]
            failure = conn.execute(
                "SELECT COUNT(*) FROM events WHERE event_type = 'LOGIN_FAILURE'"
            ).fetchone()[0]
            return {"success": success, "failure": failure}

    def get_unique_source_ips(self) -> int:
        """Gets count of unique source IPs."""
        with self.db.get_connection() as conn:
            return conn.execute("SELECT COUNT(DISTINCT source_ip) FROM events WHERE source_ip IS NOT NULL").fetchone()[0]

    def get_unique_usernames(self) -> int:
        """Gets count of unique usernames."""
        with self.db.get_connection() as conn:
            return conn.execute("SELECT COUNT(DISTINCT username) FROM events WHERE username IS NOT NULL").fetchone()[0]

    def get_failed_login_count(self) -> int:
        """Gets total count of failed logins."""
        with self.db.get_connection() as conn:
            return conn.execute("SELECT COUNT(*) FROM events WHERE event_type = 'LOGIN_FAILURE'").fetchone()[0]

    def get_successful_login_count(self) -> int:
        """Gets total count of successful logins."""
        with self.db.get_connection() as conn:
            return conn.execute("SELECT COUNT(*) FROM events WHERE event_type = 'LOGIN_SUCCESS'").fetchone()[0]
