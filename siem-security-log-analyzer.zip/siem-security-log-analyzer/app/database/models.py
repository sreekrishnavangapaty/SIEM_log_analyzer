from app.database.connection import DatabaseConnection
from app.utils.logger import setup_logger

logger = setup_logger(__name__)

def create_tables(db: DatabaseConnection):
    """Creates the necessary tables for the SIEM application."""
    
    events_table = """
    CREATE TABLE IF NOT EXISTS events (
        id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        source TEXT NOT NULL,
        event_type TEXT NOT NULL,
        username TEXT,
        source_ip TEXT,
        destination_ip TEXT,
        hostname TEXT,
        process_name TEXT,
        severity TEXT,
        message TEXT,
        raw_log TEXT,
        created_at TEXT NOT NULL
    );
    """
    
    alerts_table = """
    CREATE TABLE IF NOT EXISTS alerts (
        id TEXT PRIMARY KEY,
        alert_id TEXT UNIQUE NOT NULL,
        timestamp TEXT NOT NULL,
        rule_id TEXT NOT NULL,
        rule_name TEXT NOT NULL,
        severity TEXT NOT NULL,
        source_ip TEXT,
        username TEXT,
        event_type TEXT,
        description TEXT,
        evidence TEXT,
        occurrence_count INTEGER DEFAULT 1,
        status TEXT NOT NULL,
        first_seen TEXT NOT NULL,
        last_seen TEXT NOT NULL
    );
    """
    
    indexes = [
        "CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp);",
        "CREATE INDEX IF NOT EXISTS idx_events_source_ip ON events(source_ip);",
        "CREATE INDEX IF NOT EXISTS idx_events_username ON events(username);",
        "CREATE INDEX IF NOT EXISTS idx_events_event_type ON events(event_type);",
        "CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);",
        "CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON alerts(timestamp);"
    ]
    
    try:
        with db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(events_table)
            cursor.execute(alerts_table)
            
            for index in indexes:
                cursor.execute(index)
                
            conn.commit()
            logger.info("Database tables and indexes created successfully.")
    except Exception as e:
        logger.error(f"Error creating database tables: {e}")
        raise

if __name__ == "__main__":
    db = DatabaseConnection()
    create_tables(db)
