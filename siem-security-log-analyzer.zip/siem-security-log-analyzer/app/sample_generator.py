"""
Sample Log Generator - generates realistic syslog-format log lines
matching the existing parser formats for testing and demo purposes.
"""
import random
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional

from app.config import DATA_DIR


class SampleLogGenerator:
    """Generates sample security log lines in formats the parsers expect."""

    # Realistic data pools
    NORMAL_USERS = ['admin', 'sysadmin', 'deployer', 'webadmin', 'dbadmin']
    ATTACK_USERS = [
        'admin', 'root', 'test', 'guest', 'administrator',
        'user', 'oracle', 'postgres', 'ftpuser', 'backup',
    ]
    NORMAL_IPS = [
        '192.168.1.100', '192.168.1.101', '192.168.1.102',
        '10.1.1.50', '10.1.1.51',
    ]
    ATTACK_IPS = ['10.0.0.50', '10.0.0.100', '10.0.0.75', '10.0.0.200']
    HOSTNAMES = ['auth-server', 'web-server', 'db-server', 'app-server']
    SERVICES = [
        'nginx', 'apache2', 'postgresql', 'redis-server',
        'docker', 'cron', 'systemd-resolved',
    ]

    def __init__(self):
        self._base_time = datetime.now().replace(second=0, microsecond=0)
        self._offset = 0

    def _next_ts(self, gap_seconds: int = None) -> str:
        """Generate the next timestamp, advancing by a few seconds."""
        if gap_seconds is None:
            gap_seconds = random.randint(1, 5)
        self._offset += gap_seconds
        ts = self._base_time + timedelta(seconds=self._offset)
        return ts.strftime('%b %d %H:%M:%S')
        # Note: day may be space-padded like 'Oct  3' for single digits
        # but strftime uses zero-padded by default. Parsers handle both.

    def _pid(self) -> int:
        return random.randint(1000, 65000)

    def generate_normal(self, count: int = 50) -> List[str]:
        """Generate normal operational log lines."""
        lines = []
        hostname = random.choice(self.HOSTNAMES)

        for _ in range(count):
            ts = self._next_ts()
            roll = random.random()

            if roll < 0.3:
                # Successful login
                user = random.choice(self.NORMAL_USERS)
                ip = random.choice(self.NORMAL_IPS)
                lines.append(
                    f"{ts} {hostname} sshd[{self._pid()}]: "
                    f"Accepted password for {user} from {ip} port 22 ssh2"
                )
            elif roll < 0.45:
                # Logout / session closed
                user = random.choice(self.NORMAL_USERS)
                lines.append(
                    f"{ts} {hostname} sshd[{self._pid()}]: "
                    f"session closed for user {user}"
                )
            elif roll < 0.55:
                # Session opened
                user = random.choice(self.NORMAL_USERS)
                lines.append(
                    f"{ts} {hostname} sshd[{self._pid()}]: "
                    f"session opened for user {user}"
                )
            elif roll < 0.65:
                # Occasional failed login (isolated typos from distributed IPs)
                user = random.choice(self.NORMAL_USERS)
                ip = f"192.168.1.{random.randint(150, 250)}"
                lines.append(
                    f"{ts} {hostname} sshd[{self._pid()}]: "
                    f"Failed password for {user} from {ip} port 22 ssh2"
                )
            elif roll < 0.80:
                # Service start
                svc = random.choice(self.SERVICES)
                lines.append(
                    f"{ts} {hostname} systemd[1]: Started {svc}"
                )
            elif roll < 0.90:
                # Service stop
                svc = random.choice(self.SERVICES)
                lines.append(
                    f"{ts} {hostname} systemd[1]: Stopped {svc}"
                )
            else:
                # Sudo command (privilege change)
                user = random.choice(self.NORMAL_USERS)
                lines.append(
                    f"{ts} {hostname} sudo: {user} : "
                    f"TTY=pts/0 ; PWD=/home/{user} ; USER=root ; "
                    f"COMMAND=/bin/systemctl restart nginx"
                )

        return lines

    def generate_brute_force(
        self,
        count: int = 10,
        source_ip: str = '10.0.0.50',
        target_user: str = 'admin',
    ) -> List[str]:
        """Generate brute-force attack pattern: many failed logins
        from the same IP targeting the same user."""
        lines = []
        hostname = random.choice(self.HOSTNAMES)

        for i in range(count):
            ts = self._next_ts(gap_seconds=random.randint(2, 8))
            lines.append(
                f"{ts} {hostname} sshd[{self._pid()}]: "
                f"Failed password for {target_user} from {source_ip} "
                f"port 22 ssh2"
            )

        return lines

    def generate_account_enumeration(
        self,
        source_ip: str = '10.0.0.100',
        usernames: Optional[List[str]] = None,
    ) -> List[str]:
        """Generate account enumeration: one IP tries many usernames."""
        if usernames is None:
            usernames = self.ATTACK_USERS[:8]
        lines = []
        hostname = random.choice(self.HOSTNAMES)

        for user in usernames:
            ts = self._next_ts(gap_seconds=random.randint(2, 6))
            if random.random() < 0.5:
                lines.append(
                    f"{ts} {hostname} sshd[{self._pid()}]: "
                    f"Failed password for {user} from {source_ip} "
                    f"port 22 ssh2"
                )
            else:
                lines.append(
                    f"{ts} {hostname} sshd[{self._pid()}]: "
                    f"Failed password for invalid user {user} from "
                    f"{source_ip} port 22 ssh2"
                )

        return lines

    def generate_suspicious_login(
        self,
        source_ip: str = '10.0.0.75',
        username: str = 'admin',
        failure_count: int = 5,
    ) -> List[str]:
        """Generate suspicious login sequence: failures then success."""
        lines = []
        hostname = random.choice(self.HOSTNAMES)

        # Failures
        for _ in range(failure_count):
            ts = self._next_ts(gap_seconds=random.randint(3, 10))
            lines.append(
                f"{ts} {hostname} sshd[{self._pid()}]: "
                f"Failed password for {username} from {source_ip} "
                f"port 22 ssh2"
            )

        # Success
        ts = self._next_ts(gap_seconds=random.randint(5, 15))
        lines.append(
            f"{ts} {hostname} sshd[{self._pid()}]: "
            f"Accepted password for {username} from {source_ip} "
            f"port 22 ssh2"
        )

        return lines

    def generate_mixed(self, count: int = 100) -> List[str]:
        """Generate a mix of normal, brute-force, enumeration,
        and suspicious login patterns."""
        lines = []

        # Normal baseline (~50%)
        lines.extend(self.generate_normal(count=max(10, count // 2)))

        # Brute force attack
        lines.extend(self.generate_brute_force(
            count=8, source_ip='10.0.0.50', target_user='admin'
        ))

        # Account enumeration
        lines.extend(self.generate_account_enumeration(
            source_ip='10.0.0.100'
        ))

        # Suspicious login
        lines.extend(self.generate_suspicious_login(
            source_ip='10.0.0.75', username='admin'
        ))

        # More normal traffic
        lines.extend(self.generate_normal(count=max(5, count // 4)))

        return lines

    def save_to_file(self, lines: List[str], filename: str) -> str:
        """Save log lines to a file in the sample_logs directory.

        Returns the full file path.
        """
        output_dir = Path(DATA_DIR) / 'sample_logs'
        output_dir.mkdir(parents=True, exist_ok=True)
        filepath = output_dir / filename

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')

        return str(filepath)
