"""
End-to-End Verification of the 7 Required SOC Scenarios.
"""
import os
import shutil
from pathlib import Path
from app.config import DATA_DIR
from app.database.connection import DatabaseConnection
from app.database.models import create_tables
from app.database.repository import Repository
from app.parsers.linux_auth_parser import LinuxAuthParser
from app.parsers.normalizer import normalize_event
from app.detection.engine import DetectionEngine
from app.detection.correlation import CorrelationTracker
from app.alerts.alert_manager import AlertManager
from app.sample_generator import SampleLogGenerator
from app.analytics.statistics import SecurityStatistics
from app.analytics.trends import TrendAnalyzer


def run_e2e_tests():
    print("=" * 60)
    print("RUNNING COMPLETE SIEM END-TO-END VERIFICATION")
    print("=" * 60)

    # Use a dedicated clean database
    test_db_path = str(Path(DATA_DIR) / "test_e2e_siem.db")
    if os.path.exists(test_db_path):
        os.remove(test_db_path)

    db = DatabaseConnection(test_db_path)
    create_tables(db)
    repo = Repository(db)
    correlation = CorrelationTracker()
    engine = DetectionEngine(correlation)
    alert_mgr = AlertManager(repo)
    gen = SampleLogGenerator()
    parser = LinuxAuthParser()

    def process_pipeline(lines):
        stats = {'events': 0, 'alerts': 0, 'alert_ids': []}
        for line in lines:
            parsed = parser.parse_line(line)
            if not parsed:
                continue
            normalized = normalize_event(parsed, parser.parser_name, line)
            if not normalized:
                continue
            repo.insert_event(normalized)
            stats['events'] += 1

            detections = engine.process_event(normalized)
            for det in detections:
                aid = alert_mgr.process_detection(det)
                if aid:
                    stats['alerts'] += 1
                    stats['alert_ids'].append(aid)
        return stats

    # -------------------------------------------------------------
    # TEST 1 — NORMAL LOGS
    # -------------------------------------------------------------
    print("\n[TEST 1] Testing NORMAL LOGS...")
    engine.reset()
    normal_lines = gen.generate_normal(count=30)
    res1 = process_pipeline(normal_lines)
    alerts1 = repo.get_alerts()
    print(f" -> Processed {res1['events']} normal events. Total alerts generated: {len(alerts1)}")
    assert len(alerts1) == 0, f"Expected 0 alerts for normal logs, got {len(alerts1)}"
    print(" PASS: Normal logs produced 0 false alerts.")

    # -------------------------------------------------------------
    # TEST 2 — BRUTE FORCE
    # -------------------------------------------------------------
    print("\n[TEST 2] Testing BRUTE FORCE (RULE_001)...")
    engine.reset()
    bf_lines = gen.generate_brute_force(count=10, source_ip="10.0.0.50", target_user="admin")
    res2 = process_pipeline(bf_lines)
    alerts2 = [a for a in repo.get_alerts() if a['rule_id'] == 'RULE_001']
    print(f" -> Generated {len(alerts2)} BRUTE_FORCE alert(s).")
    assert len(alerts2) >= 1, "Expected BRUTE_FORCE alert to be created!"
    bf_alert = alerts2[0]
    print(f" -> Alert ID: {bf_alert['alert_id']}")
    print(f" -> Evidence: {bf_alert['evidence']}")
    print(f" -> Occurrence Count: {bf_alert['occurrence_count']}")
    assert "exceeding the configured threshold of 5" in bf_alert['evidence']
    assert bf_alert['source_ip'] == "10.0.0.50"
    print(" PASS: Brute force attack correctly detected and alert created with evidence.")

    # -------------------------------------------------------------
    # TEST 3 — ACCOUNT ENUMERATION
    # -------------------------------------------------------------
    print("\n[TEST 3] Testing ACCOUNT ENUMERATION (RULE_002)...")
    engine.reset()
    enum_lines = gen.generate_account_enumeration(source_ip="10.0.0.100")
    res3 = process_pipeline(enum_lines)
    alerts3 = [a for a in repo.get_alerts() if a['rule_id'] == 'RULE_002']
    print(f" -> Generated {len(alerts3)} ACCOUNT_ENUMERATION alert(s).")
    assert len(alerts3) >= 1, "Expected ACCOUNT_ENUMERATION alert to be created!"
    enum_alert = alerts3[0]
    print(f" -> Alert ID: {enum_alert['alert_id']}")
    print(f" -> Evidence: {enum_alert['evidence']}")
    assert enum_alert['source_ip'] == "10.0.0.100"
    assert "exceeding the configured threshold of 3" in enum_alert['evidence']
    print(" PASS: Account enumeration correctly detected and alert created with evidence.")

    # -------------------------------------------------------------
    # TEST 4 — SUSPICIOUS LOGIN
    # -------------------------------------------------------------
    print("\n[TEST 4] Testing SUSPICIOUS LOGIN SEQUENCE (RULE_003)...")
    engine.reset()
    susp_lines = gen.generate_suspicious_login(source_ip="10.0.0.75", username="target_user", failure_count=4)
    res4 = process_pipeline(susp_lines)
    alerts4 = [a for a in repo.get_alerts() if a['rule_id'] == 'RULE_003']
    print(f" -> Generated {len(alerts4)} SUSPICIOUS_LOGIN_SEQUENCE alert(s).")
    assert len(alerts4) >= 1, "Expected SUSPICIOUS_LOGIN_SEQUENCE alert to be created!"
    susp_alert = alerts4[0]
    print(f" -> Alert ID: {susp_alert['alert_id']}")
    print(f" -> Evidence: {susp_alert['evidence']}")
    assert "Suspicious authentication sequence" in susp_alert['evidence']
    assert susp_alert['source_ip'] == "10.0.0.75"
    assert susp_alert['username'] == "target_user"
    print(" PASS: Suspicious login sequence detected and alert created.")

    # -------------------------------------------------------------
    # TEST 5 — ALERT STATUS LIFECYCLE
    # -------------------------------------------------------------
    print("\n[TEST 5] Testing ALERT STATUS LIFECYCLE...")
    target_aid = bf_alert['alert_id']
    # Transition to INVESTIGATING
    assert alert_mgr.update_status(target_aid, "INVESTIGATING")
    updated = repo.get_alert_by_id(target_aid)
    assert updated['status'] == "INVESTIGATING"
    print(f" -> Status updated to: {updated['status']}")

    # Transition to RESOLVED
    assert alert_mgr.update_status(target_aid, "RESOLVED")
    updated2 = repo.get_alert_by_id(target_aid)
    assert updated2['status'] == "RESOLVED"
    print(f" -> Status updated to: {updated2['status']}")
    print(" PASS: Alert status transitioned NEW -> INVESTIGATING -> RESOLVED and persisted.")

    # -------------------------------------------------------------
    # TEST 6 — REAL ANALYTICS FROM SQLITE
    # -------------------------------------------------------------
    print("\n[TEST 6] Testing REAL ANALYTICS FROM SQLITE...")
    sec_stats = SecurityStatistics(repo)
    overview = sec_stats.get_overview()
    print(f" -> Total Events: {overview['total_events']}")
    print(f" -> Total Alerts: {overview['total_alerts']}")
    print(f" -> Failed Logins: {overview['failed_logins']}")
    print(f" -> Successful Logins: {overview['successful_logins']}")
    print(f" -> Unique Source IPs: {overview['unique_ips']}")
    assert overview['total_events'] > 0
    assert overview['total_alerts'] > 0
    assert overview['failed_logins'] > 0

    top_ips = sec_stats.get_top_suspicious_ips()
    assert len(top_ips) > 0
    print(f" -> Top Suspicious IPs: {top_ips[:3]}")
    print(" PASS: Analytics calculated authentic SQLite metrics.")

    # -------------------------------------------------------------
    # TEST 7 — REPORTS & CSV EXPORTS
    # -------------------------------------------------------------
    print("\n[TEST 7] Testing REPORTS & CSV EXPORTS...")
    import pandas as pd
    events = repo.get_events(limit=1000)
    alerts = repo.get_alerts(limit=1000)
    df_events = pd.DataFrame(events)
    df_alerts = pd.DataFrame(alerts)
    csv_ev = df_events.to_csv(index=False)
    csv_al = df_alerts.to_csv(index=False)
    assert len(csv_ev) > 100
    assert len(csv_al) > 100
    print(f" -> Exported Events CSV: {len(df_events)} records")
    print(f" -> Exported Alerts CSV: {len(df_alerts)} records")
    print(" PASS: CSV export functional with authentic database records.")

    # Clean up test database
    if os.path.exists(test_db_path):
        os.remove(test_db_path)

    print("\n" + "=" * 60)
    print("ALL 7 END-TO-END SOC VERIFICATION TESTS PASSED SUCCESSFULLY!")
    print("=" * 60)

if __name__ == '__main__':
    run_e2e_tests()
