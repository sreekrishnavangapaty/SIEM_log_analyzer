# SIEM Security Project Interview Guide

This guide prepares you to explain the architectural, engineering, and cybersecurity decisions made throughout the project during technical interviews.

---

## 1. Project Overview & Elevator Pitch

> *"I designed and built a lightweight Security Information and Event Management (SIEM) log analyzer in Python. The system processes heterogeneous logs (Linux Auth, Syslog, and Windows Security Event Logs), normalizes them into a unified security schema, runs a streaming detection and correlation engine to catch attacks like brute force, account enumeration, and suspicious login sequences, deduplicates active alerts, persists them into SQLite with optimized indexing, and visualizes SOC operations in an interactive 9-page Streamlit console."*

---

## 2. Core Architectural Questions

### Q: Why normalize logs instead of writing detection rules against raw log strings?
- **Answer**: 
  - Different operating systems format identical security concepts differently. For example, a successful login is Event ID 4624 in Windows Security Event CSVs, but `"Accepted password for..."` in Linux OpenSSH syslog.
  - Normalization extracts semantic fields (`timestamp`, `source_ip`, `username`, `event_type`, `severity`) into a standardized schema (`SecurityEvent`).
  - This decouples detection rules from parsing logic: detection rules can operate purely against normalized concepts like `LOGIN_FAILURE` without needing to understand OS-specific log nuances.

### Q: How does the detection engine avoid race conditions and handle high throughput?
- **Answer**:
  - The pipeline uses a streaming architecture where events are parsed, normalized, and evaluated sequentially as generators.
  - The `CorrelationTracker` maintains in-memory sliding windows using timestamp comparisons and periodically purges expired events to prevent unbounded memory growth.
  - Alerts are stored in SQLite using indexed lookups, and alerts from identical sources within an active window are deduplicated by incrementing `occurrence_count` rather than issuing redundant rows.

### Q: How does Alert Deduplication work in this system?
- **Answer**:
  - In a real brute-force attack, an attacker may generate thousands of failed attempts. Creating a new alert row for every failure causes alert fatigue and exhausts database storage.
  - The `AlertManager` checks `find_existing_alert(rule_id, source_ip)` for existing active alerts in `NEW` or `INVESTIGATING` states.
  - If found, it updates the existing alert's `occurrence_count`, updates `last_seen`, and appends new evidence.
  - If no active alert exists (or previous alerts are marked `RESOLVED`), a new alert is generated.

### Q: Why did you choose SQLite and Matplotlib instead of MongoDB or Plotly?
- **Answer**:
  - **SQLite**: Provides zero-configuration ACID transactions with atomic consistency and fast index scans for localized single-node SOC deployments. No external server daemon is required, making it lightweight and self-contained.
  - **Matplotlib**: Generates deterministic, lightweight static figures rendered via `st.pyplot()`, avoiding the heavy JavaScript/WebGL overhead, memory footprints, and bundle size of Plotly in browser sessions.

---

## 3. Detection Rule Deep-Dive

### Q: How do you differentiate between a targeted brute force and account enumeration?
- **Answer**:
  - **Brute Force (`RULE_001`)**: High volume of failures from a single IP targeting a single username or small set of accounts (vertical attack).
  - **Account Enumeration (`RULE_002`)**: High diversity of distinct usernames from a single IP (horizontal attack, e.g. dictionary attack against `admin`, `guest`, `oracle`, `root`, `backup`).

### Q: Why is `RULE_003` (Suspicious Login Correlation) labeled "Suspicious" rather than "Definite Compromise"?
- **Answer**:
  - A sequence of 4 failed passwords followed by a success can legitimately happen if a user forgot their password and remembered it on the 5th attempt.
  - Marking it as an absolute compromise leads to high false positive rates and unnecessary panic.
  - Labeling it as suspicious prompts the SOC analyst to investigate without automatically blocking access.

---

## 4. SOC Workflow & Investigation Scenarios

### Q: Walk me through how an analyst investigates an alert in your dashboard.
1. The analyst opens the **Security Alerts** page and filters for `CRITICAL` or `HIGH` severity alerts in `NEW` status.
2. They click into **Alert Investigation** and select the alert.
3. The dashboard displays:
   - Alert metadata (Rule, Severity, Status, First Seen, Last Seen, Occurrences).
   - The concrete detection evidence string explaining why the rule triggered.
   - Related raw events from that source IP during the time window.
   - Tailored investigation guidance.
4. If investigation confirms legitimate developer activity, the analyst updates status to `FALSE_POSITIVE`. If malicious, they escalate and update status to `RESOLVED` after containment.
