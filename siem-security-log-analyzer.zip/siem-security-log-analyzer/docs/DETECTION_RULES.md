# SIEM Detection Rules Specification

This document details the detection rules implemented in the SIEM engine, their logic, severity levels, configuration parameters, and generated evidence.

---

## RULE_001: Repeated Failed Logins (Brute Force)

- **Rule ID**: `RULE_001`
- **Rule Name**: `BRUTE_FORCE`
- **Severity**: `HIGH`
- **Target Event Types**: `LOGIN_FAILURE`, `INVALID_USER`
- **Description**: Detects repeated failed authentication attempts originating from the same source IP address within a configurable time window.
- **Default Parameters**:
  - `failed_login_threshold`: 5 attempts
  - `failed_login_window`: 300 seconds (5 minutes)
- **Detection Logic**:
  1. For each `LOGIN_FAILURE` or `INVALID_USER` event, record the event in the `CorrelationTracker` under `source_ip`.
  2. Filter all failed attempts from `source_ip` within `now - failed_login_window`.
  3. If the count of matching attempts >= `failed_login_threshold`, trigger an alert.
- **Evidence Output**:
  ```
  Source IP 10.0.0.50 generated 8 failed login attempts within 300 seconds, exceeding the configured threshold of 5. Target username: admin. First seen: 2026-10-03T14:30:00. Last seen: 2026-10-03T14:32:15.
  ```
- **Analyst Remediation**:
  - Verify if the source IP belongs to an internal developer, automated scanner, or external unauthorized host.
  - Review whether any subsequent login was successful.
  - Temporarily throttle or block the source IP at the network firewall if unauthorized.

---

## RULE_002: Account Enumeration / Credential Stuffing

- **Rule ID**: `RULE_002`
- **Rule Name**: `ACCOUNT_ENUMERATION`
- **Severity**: `HIGH`
- **Target Event Types**: `LOGIN_FAILURE`, `INVALID_USER`
- **Description**: Detects a single source IP attempting authentication against multiple different usernames within a time window, indicating horizontal brute-force, username enumeration, or credential stuffing.
- **Default Parameters**:
  - `account_enum_threshold`: 3 unique usernames
  - `account_enum_window`: 300 seconds (5 minutes)
- **Detection Logic**:
  1. Record each distinct username targeted by `source_ip` in failed logins along with its timestamp.
  2. Filter distinct usernames seen within `now - account_enum_window`.
  3. If the count of distinct usernames >= `account_enum_threshold`, trigger an alert.
- **Evidence Output**:
  ```
  Source IP 10.0.0.100 attempted authentication against 6 unique usernames within 300 seconds, exceeding the configured threshold of 3. Usernames targeted: ['admin', 'guest', 'oracle', 'postgres', 'root', 'test']. First seen: 2026-10-03T14:31:00. Last seen: 2026-10-03T14:32:00.
  ```
- **Analyst Remediation**:
  - Identify whether common default system usernames (`root`, `admin`, `guest`) were targeted.
  - Correlate with threat intelligence feeds to check if the source IP is a known scanner/botnet.
  - Audit accounts that were targeted to ensure strong multi-factor authentication (MFA).

---

## RULE_003: Suspicious Login Correlation (Failures Followed by Success)

- **Rule ID**: `RULE_003`
- **Rule Name**: `SUSPICIOUS_LOGIN_SEQUENCE`
- **Severity**: `MEDIUM`
- **Target Event Types**: `LOGIN_SUCCESS` (evaluating preceding `LOGIN_FAILURE` sequence)
- **Description**: Detects an authentication sequence where multiple failed login attempts are immediately followed by a successful login for the same account and source IP within the correlation window.
- **Default Parameters**:
  - `suspicious_login_failures_before_success`: 3 consecutive failures
  - `suspicious_login_window`: 300 seconds (5 minutes)
- **Detection Logic**:
  1. Maintain chronological list of auth events for `(source_ip, username)`.
  2. On receiving `LOGIN_SUCCESS`, inspect the preceding consecutive events within the correlation window.
  3. If the number of consecutive preceding failures >= 3, trigger an alert.
- **Evidence Output**:
  ```
  Suspicious authentication sequence detected from source IP 10.0.0.75 for user admin: 4 failed attempts followed by a successful login within 300 seconds. This pattern requires investigation to determine if the account was compromised. First failure: 2026-10-03T14:30:10. Successful login: 2026-10-03T14:31:40.
  ```
- **Analyst Remediation**:
  - Contact the legitimate account owner to confirm whether they experienced password typos or if their credentials were compromised.
  - Verify if the login session IP matches the employee's usual subnet or VPN exit node.
  - If suspicious, revoke active sessions and enforce password reset.

---

## RULE_004: Privilege Escalation Monitoring

- **Rule ID**: `RULE_004`
- **Rule Name**: `PRIVILEGE_ESCALATION`
- **Severity**: `CRITICAL`
- **Target Event Types**: `PRIVILEGE_CHANGE` (evaluating preceding failed attempts)
- **Description**: Detects sensitive administrative privilege changes (e.g. `sudo` execution or Windows Event 4672) occurring shortly after failed authentication events on the same host or user.
- **Default Parameters**:
  - `privilege_escalation_window`: 600 seconds (10 minutes)
- **Detection Logic**:
  1. On receiving `PRIVILEGE_CHANGE`, check if the user or source IP experienced prior failed authentication attempts within the window.
  2. If prior failures exist, trigger a high-priority incident alert.
- **Evidence Output**:
  ```
  Privilege escalation activity detected for user admin from source IP 10.0.0.50. This user/source had 3 failed authentication attempts before gaining elevated privileges within 600 seconds. First failure: 2026-10-03T14:25:00. Privilege change: 2026-10-03T14:30:00.
  ```
- **Analyst Remediation**:
  - Check the exact command executed via `sudo` or the privilege token assigned.
  - Verify if privileged access follows an approved change request or ticket.
