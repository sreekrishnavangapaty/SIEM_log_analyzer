# SIEM System Architecture

## 1. High-Level Data Flow

```
+--------------------+
| Raw Log File       |  (Linux Syslog, Windows CSV)
+--------------------+
          |
          v
+--------------------+
| LogReader          |  (Line-by-line reading with encoding error tolerance)
+--------------------+
          |
          v
+--------------------+
| BaseParser         |  (LinuxAuthParser, LinuxSystemParser, WindowsSecurityParser)
+--------------------+
          |
          v
+--------------------+
| Normalizer         |  (Standardized timestamp, schema, severity mapping)
+--------------------+
          |
          +-------------------------------+
          |                               |
          v                               v
+--------------------+          +--------------------+
| Events Table       |          | DetectionEngine    |  (Evaluates rules)
| (SQLite Storage)   |          +--------------------+
+--------------------+                    |
                                          v
                                +--------------------+
                                | CorrelationTracker |  (Time-window state)
                                +--------------------+
                                          |
                                          v
                                +--------------------+
                                | AlertManager       |  (Deduplication & alerts)
                                +--------------------+
                                          |
                                          v
                                +--------------------+
                                | Alerts Table       |
                                | (SQLite Storage)   |
                                +--------------------+
                                          |
                                          v
                                +--------------------+
                                | Analytics Layer    |
                                +--------------------+
                                          |
                                          v
                                +--------------------+
                                | Streamlit SOC UI   |
                                +--------------------+
```

---

## 2. Component Breakdown

### Ingestion (`app/ingestion/log_reader.py`)
- Reads files lazily using Python generator iterators to maintain small memory footprint.
- Gracefully handles missing files, permission errors, and invalid UTF-8 byte sequences using `replace` error handling.

### Parsers (`app/parsers/`)
- Polymorphic parser architecture using `BaseParser` abstract base class with `can_parse()` and `parse_line()`.
- **LinuxAuthParser**: Regex patterns for OpenSSH daemon (`sshd`) and `sudo`.
- **LinuxSystemParser**: Regex patterns for `systemd` service management and kernel warnings.
- **WindowsSecurityParser**: Parses Windows Security Event log CSV rows mapping Event IDs (4624, 4625, 4634, 4672).

### Normalization (`app/parsers/normalizer.py`)
- Converts divergent log timestamp formats (Syslog `Oct 3 14:30:00` vs ISO strings) into ISO 8601 (`YYYY-MM-DDTHH:MM:SS`).
- Maps event types to baseline severity levels:
  - `LOGIN_SUCCESS`, `LOGOUT`, `SERVICE_START`, `SERVICE_STOP` -> `LOW`
  - `LOGIN_FAILURE`, `INVALID_USER`, `SYSTEM_WARNING` -> `MEDIUM`
  - `PRIVILEGE_CHANGE`, `SUSPICIOUS_ACCESS` -> `HIGH`

### Detection & Correlation (`app/detection/`)
- **`thresholds.py`**: Centralized threshold configuration module supporting runtime parameter mutation from the dashboard Settings page.
- **`rules.py`**: Immutable dataclass rule registry storing rule definitions, severity, logic descriptions, and human-readable evidence formatting strings.
- **`correlation.py`**: In-memory state tracking (`CorrelationTracker`) implementing sliding correlation windows. Tracks:
  - Timestamped failed authentication history by source IP.
  - Set of unique targeted usernames by source IP.
  - Per-account authentication sequences (`LOGIN_FAILURE* -> LOGIN_SUCCESS`).
  - History pruning to prevent memory exhaustion.
- **`engine.py`**: Synchronously inspects each normalized event against all relevant rules based on event type.

### Alert Management (`app/alerts/alert_manager.py`)
- Deduplication: Queries SQLite via `find_existing_alert(rule_id, source_ip)` to locate active alerts in `NEW` or `INVESTIGATING` states.
- If an active alert matches, it increments `occurrence_count`, updates `last_seen`, and appends new evidence.
- If no active alert exists, it mints a new unique alert identifier (`ALT-YYYYMMDD-XXXX`) and persists the alert.
- Supports lifecycle status transitions: `NEW`, `INVESTIGATING`, `RESOLVED`, `FALSE_POSITIVE`.

### Database & Repository (`app/database/`)
- Built on SQLite using `DatabaseConnection` with context management.
- Indexed columns on high-frequency query paths (`timestamp`, `source_ip`, `username`, `event_type`, `status`).
- `Repository` isolates all SQL operations and returns standard Python dictionaries.

### Analytics & Visualizations (`app/analytics/` & `dashboard/app.py`)
- Real-time aggregation over SQLite tables for SOC metrics.
- Matplotlib visualizations with a consistent dark security theme.
- Interactive investigation drill-down with linked event queries and defensive remediation playbooks.
