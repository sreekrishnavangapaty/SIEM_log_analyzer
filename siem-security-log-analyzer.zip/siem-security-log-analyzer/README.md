# SIEM — Security Information and Event Management Log Analyzer

A lightweight, fully functional Security Operations Center (SOC) log analyzer and SIEM system built in Python. Designed for ingesting, normalizing, detecting cyber threats, correlating multi-stage attacks, managing alerts, and visualizing incidents in a real-time Streamlit dashboard.

---

## Architecture Overview

```
LOG FILE (Syslog / Windows Security CSV)
   ↓
LOG READER (app/ingestion/log_reader.py)
   ↓
LOG PARSER (Linux Auth, Linux System, Windows Security)
   ↓
NORMALIZATION (app/parsers/normalizer.py)
   ↓
DETECTION ENGINE (app/detection/engine.py & rules.py)
   ↓
ALERT MANAGER (app/alerts/alert_manager.py)
   ↓
SQLITE DATABASE (siem.db — events & alerts tables)
   ↓
ANALYTICS (app/analytics/statistics.py & trends.py)
   ↓
STREAMLIT SOC DASHBOARD (dashboard/app.py)
```

---

## Key Features

1. **Multi-Source Log Ingestion & Parsing**:
   - **Linux Authentication Logs** (`/var/log/auth.log`): SSH successful/failed logins, invalid users, logouts, sudo privilege elevation.
   - **Linux System Logs** (`/var/log/syslog`): Systemd service starts/stops, system warnings, suspicious access / permission denied.
   - **Windows Security Event Logs** (CSV format): Event ID 4624 (Success Logon), 4625 (Failed Logon), 4634 (Logoff), 4672 (Special Privileges Assigned).

2. **Event Normalization**:
   - Standardizes timestamps to ISO 8601 format.
   - Standardizes event types (`LOGIN_SUCCESS`, `LOGIN_FAILURE`, `INVALID_USER`, `PRIVILEGE_CHANGE`, `LOGOUT`, etc.).
   - Assigns standard severity ratings (`LOW`, `MEDIUM`, `HIGH`, `CRITICAL`).

3. **Detection Engine & Correlation**:
   - **RULE_001 (BRUTE_FORCE)**: Flags repeated failed login attempts from a single source IP exceeding threshold (default: 5 failures within 300s).
   - **RULE_002 (ACCOUNT_ENUMERATION)**: Flags single source IP targeting multiple distinct usernames (default: 3 unique usernames within 300s).
   - **RULE_003 (SUSPICIOUS_LOGIN_SEQUENCE)**: Detects repeated failures followed by a success from the same source IP/username within the correlation window.
   - **RULE_004 (PRIVILEGE_ESCALATION)**: Flags privilege escalation attempts (e.g. sudo) following prior failed authentication attempts.

4. **Alert Manager & Deduplication**:
   - Auto-deduplicates recurring alerts from the same source and rule, updating `occurrence_count` and `last_seen` timestamp rather than flooding the database.
   - Lifecycle status tracking: `NEW` → `INVESTIGATING` → `RESOLVED` / `FALSE_POSITIVE`.

5. **SQLite Storage & Analytics**:
   - Relational persistence with indexed queries on timestamps, source IP, username, event type, and status.
   - Zero hardcoded numbers; all dashboard statistics, distributions, and timelines are queried live from SQLite.

6. **SOC Security Dashboard (Streamlit & Matplotlib)**:
   - **Overview**: Real-time SOC metrics, events timeline, alerts by severity, and recent alert feed.
   - **Security Events**: Filterable log event explorer.
   - **Security Alerts**: Severity-badged alerts table with live status indicators.
   - **Alert Investigation**: Detailed drill-down showing alert metadata, evidence explanation, contributing event timeline, and investigative guidance. Status updates persist directly to SQLite.
   - **Threat Analysis**: Matplotlib visualizations for suspicious source IPs, auth success vs. failure ratios, event distributions, and detection rule frequencies.
   - **Detection Rules**: Catalog of active detection logic, thresholds, and evidence templates.
   - **Log Ingestion**: File uploader + interactive Demo scenario generator running the complete detection pipeline.
   - **Reports**: Live CSV export for events and alerts, plus security summary reports.
   - **Settings**: Dynamic configuration for all detection thresholds and time windows.

---

## Installation & Setup

1. **Clone and enter the repository**:
   ```bash
   cd siem-security-log-analyzer
   ```

2. **Create and activate a virtual environment**:
   ```bash
   python -m venv venv
   # On Windows:
   venv\Scripts\activate
   # On Linux/macOS:
   source venv/bin/activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Initialize database & environment**:
   Copy `.env.example` to `.env` if customization is needed:
   ```bash
   cp .env.example .env
   ```

---

## Running the Application

### 1. Launch the Streamlit Dashboard
```bash
streamlit run dashboard/app.py
```
Open your browser at `http://localhost:8501`.

### 2. Run Test Suite
```bash
pytest
```

---

## Directory Structure

```
siem-security-log-analyzer/
├── app/
│   ├── alerts/
│   │   ├── __init__.py
│   │   └── alert_manager.py       # Alert creation, deduplication & status
│   ├── analytics/
│   │   ├── __init__.py
│   │   ├── statistics.py          # Real-time SQLite metrics calculation
│   │   └── trends.py              # Attack timeline & threat analysis
│   ├── database/
│   │   ├── __init__.py
│   │   ├── connection.py          # SQLite connection manager
│   │   ├── models.py              # Schema definitions & index creation
│   │   └── repository.py          # Database queries & data access layer
│   ├── detection/
│   │   ├── __init__.py
│   │   ├── correlation.py         # State tracking & time window correlation
│   │   ├── engine.py              # Pipeline detection orchestrator
│   │   ├── rules.py               # Rule definitions & evidence templates
│   │   └── thresholds.py          # Centralized configurable thresholds
│   ├── ingestion/
│   │   ├── __init__.py
│   │   └── log_reader.py          # Resilient file/stream line reader
│   ├── parsers/
│   │   ├── __init__.py
│   │   ├── base_parser.py         # Base parser abstract class
│   │   ├── linux_auth_parser.py   # Linux /var/log/auth.log syslog parser
│   │   ├── linux_system_parser.py # Linux /var/log/syslog parser
│   │   ├── windows_parser.py      # Windows Security CSV parser
│   │   └── normalizer.py          # Normalization to SecurityEvent schema
│   ├── utils/
│   │   ├── __init__.py
│   │   └── logger.py              # Application logging utility
│   ├── config.py                  # Environment & threshold configuration
│   └── sample_generator.py        # Demo log generator for realistic attacks
├── dashboard/
│   ├── __init__.py
│   └── app.py                     # Streamlit 9-page SOC console
├── docs/
│   ├── ARCHITECTURE.md            # Detailed pipeline & data model design
│   ├── DETECTION_RULES.md         # Full detection logic & evidence guide
│   └── INTERVIEW_GUIDE.md         # Technical Q&A and architecture rationale
├── tests/
│   ├── __init__.py
│   ├── test_parsers.py            # Parser regex & format tests
│   ├── test_normalization.py      # Normalization tests
│   ├── test_detection.py          # Rule & correlation tests
│   ├── test_alerts.py             # Deduplication & status lifecycle tests
│   └── test_database.py           # SQLite repository query tests
├── data/                          # SQLite db, sample logs & processed files
├── .env.example                   # Default environment configuration
├── requirements.txt               # Project dependencies
└── README.md
```
