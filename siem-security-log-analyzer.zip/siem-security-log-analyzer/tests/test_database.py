"""
Tests for Database, Tables, Indexes, and Repository.
"""
import pytest
from app.database.connection import DatabaseConnection
from app.database.models import create_tables
from app.database.repository import Repository


@pytest.fixture
def repo(tmp_path):
    db_file = tmp_path / "siem_test.db"
    conn = DatabaseConnection(str(db_file))
    create_tables(conn)
    return Repository(conn)


class TestDatabaseRepository:
    def test_insert_and_get_events(self, repo):
        event = {
            'id': 'evt-1',
            'timestamp': '2026-10-03T12:00:00',
            'source': 'linux_auth',
            'event_type': 'LOGIN_SUCCESS',
            'username': 'bob',
            'source_ip': '192.168.1.20',
            'destination_ip': '192.168.1.1',
            'hostname': 'srv-1',
            'process_name': 'sshd',
            'severity': 'LOW',
            'message': 'Accepted password for bob',
            'raw_log': 'raw log line',
            'created_at': '2026-10-03T12:00:01'
        }
        eid = repo.insert_event(event)
        assert eid == 'evt-1'

        events = repo.get_events(limit=10)
        assert len(events) == 1
        assert events[0]['username'] == 'bob'
        assert events[0]['event_type'] == 'LOGIN_SUCCESS'

    def test_filtered_events(self, repo):
        repo.insert_event({
            'timestamp': '2026-10-03T12:00:00',
            'source': 'linux_auth',
            'event_type': 'LOGIN_FAILURE',
            'username': 'attacker',
            'source_ip': '10.0.0.5'
        })
        repo.insert_event({
            'timestamp': '2026-10-03T12:01:00',
            'source': 'linux_auth',
            'event_type': 'LOGIN_SUCCESS',
            'username': 'legit',
            'source_ip': '192.168.1.5'
        })

        failures = repo.get_events(event_type='LOGIN_FAILURE')
        assert len(failures) == 1
        assert failures[0]['username'] == 'attacker'

        successes = repo.get_events(event_type='LOGIN_SUCCESS')
        assert len(successes) == 1
        assert successes[0]['username'] == 'legit'

    def test_statistics_aggregation(self, repo):
        repo.insert_event({
            'timestamp': '2026-10-03T12:00:00',
            'source': 'linux_auth',
            'event_type': 'LOGIN_FAILURE',
            'username': 'u1',
            'source_ip': '10.0.0.1'
        })
        repo.insert_event({
            'timestamp': '2026-10-03T12:00:01',
            'source': 'linux_auth',
            'event_type': 'LOGIN_FAILURE',
            'username': 'u2',
            'source_ip': '10.0.0.1'
        })
        repo.insert_event({
            'timestamp': '2026-10-03T12:00:02',
            'source': 'linux_auth',
            'event_type': 'LOGIN_SUCCESS',
            'username': 'u3',
            'source_ip': '10.0.0.2'
        })

        assert repo.get_failed_login_count() == 2
        assert repo.get_successful_login_count() == 1
        assert repo.get_unique_source_ips() == 2
        assert repo.get_unique_usernames() == 3

        stats = repo.get_event_stats()
        assert stats['total_events'] == 3
