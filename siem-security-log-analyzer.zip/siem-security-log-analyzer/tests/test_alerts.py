"""
Tests for Alert Manager (creation, deduplication, status updates).
"""
import pytest
from app.database.connection import DatabaseConnection
from app.database.models import create_tables
from app.database.repository import Repository
from app.alerts.alert_manager import AlertManager


@pytest.fixture
def test_repo(tmp_path):
    db_file = tmp_path / "test_siem.db"
    conn = DatabaseConnection(str(db_file))
    create_tables(conn)
    return Repository(conn)


@pytest.fixture
def alert_mgr(test_repo):
    return AlertManager(test_repo)


class TestAlertManager:
    def test_create_and_deduplicate_alert(self, alert_mgr, test_repo):
        detection = {
            'rule_id': 'RULE_001',
            'rule_name': 'BRUTE_FORCE',
            'severity': 'HIGH',
            'source_ip': '192.168.1.50',
            'username': 'admin',
            'event_type': 'LOGIN_FAILURE',
            'description': 'Repeated failed logins',
            'evidence': '5 failures detected',
            'count': 5,
            'first_seen': '2026-10-03T10:00:00',
            'last_seen': '2026-10-03T10:01:00'
        }

        # 1. Create alert
        aid1 = alert_mgr.process_detection(detection)
        assert aid1 is not None
        assert aid1.startswith('ALT-')

        alert_record = alert_mgr.get_alert_details(aid1)
        assert alert_record is not None
        assert alert_record['occurrence_count'] == 5
        assert alert_record['status'] == 'NEW'

        # 2. Subsequent detection from same IP and rule should deduplicate
        detection2 = dict(detection)
        detection2['last_seen'] = '2026-10-03T10:02:00'
        detection2['evidence'] = '6 failures detected'
        aid2 = alert_mgr.process_detection(detection2)

        # Same alert ID returned
        assert aid2 == aid1
        updated = alert_mgr.get_alert_details(aid1)
        assert updated['occurrence_count'] == 6
        assert '6 failures detected' in updated['evidence']

    def test_update_status(self, alert_mgr, test_repo):
        detection = {
            'rule_id': 'RULE_002',
            'rule_name': 'ACCOUNT_ENUMERATION',
            'severity': 'HIGH',
            'source_ip': '10.0.0.1',
            'username': 'root',
            'description': 'Enumeration',
            'evidence': 'evidence',
            'count': 3,
            'first_seen': '2026-10-03T10:00:00',
            'last_seen': '2026-10-03T10:01:00'
        }
        aid = alert_mgr.process_detection(detection)

        # Transition NEW -> INVESTIGATING
        assert alert_mgr.update_status(aid, 'INVESTIGATING')
        rec = alert_mgr.get_alert_details(aid)
        assert rec['status'] == 'INVESTIGATING'

        # Transition INVESTIGATING -> RESOLVED
        assert alert_mgr.update_status(aid, 'RESOLVED')
        rec = alert_mgr.get_alert_details(aid)
        assert rec['status'] == 'RESOLVED'

        # Invalid status should return False
        assert not alert_mgr.update_status(aid, 'INVALID_STATUS')
