"""
Tests for log parsers (Linux Auth, Linux System, Windows Security).
"""
import pytest
from app.parsers.linux_auth_parser import LinuxAuthParser
from app.parsers.linux_system_parser import LinuxSystemParser
from app.parsers.windows_parser import WindowsSecurityParser


@pytest.fixture
def auth_parser():
    return LinuxAuthParser()


@pytest.fixture
def system_parser():
    return LinuxSystemParser()


@pytest.fixture
def windows_parser():
    return WindowsSecurityParser()


class TestLinuxAuthParser:
    def test_failed_password(self, auth_parser):
        line = "Oct  3 14:30:01 auth-server sshd[12345]: Failed password for admin from 192.168.1.100 port 22 ssh2"
        assert auth_parser.can_parse(line)
        res = auth_parser.parse_line(line)
        assert res is not None
        assert res['event_type'] == 'LOGIN_FAILURE'
        assert res['username'] == 'admin'
        assert res['source_ip'] == '192.168.1.100'
        assert res['hostname'] == 'auth-server'

    def test_invalid_user(self, auth_parser):
        line = "Oct  3 14:30:05 auth-server sshd[12346]: Failed password for invalid user guest from 10.0.0.10 port 22 ssh2"
        res = auth_parser.parse_line(line)
        assert res is not None
        assert res['event_type'] == 'LOGIN_FAILURE'
        assert res['username'] == 'guest'
        assert res['source_ip'] == '10.0.0.10'

    def test_accepted_password(self, auth_parser):
        line = "Oct  3 14:30:10 auth-server sshd[12347]: Accepted password for sysadmin from 192.168.1.50 port 22 ssh2"
        res = auth_parser.parse_line(line)
        assert res is not None
        assert res['event_type'] == 'LOGIN_SUCCESS'
        assert res['username'] == 'sysadmin'
        assert res['source_ip'] == '192.168.1.50'

    def test_session_closed(self, auth_parser):
        line = "Oct  3 14:35:00 auth-server sshd[12347]: session closed for user sysadmin"
        res = auth_parser.parse_line(line)
        assert res is not None
        assert res['event_type'] == 'LOGOUT'
        assert res['username'] == 'sysadmin'

    def test_sudo_privilege(self, auth_parser):
        line = "Oct  3 14:36:00 auth-server sudo: sysadmin : TTY=pts/0 ; PWD=/home/sysadmin ; USER=root ; COMMAND=/bin/bash"
        res = auth_parser.parse_line(line)
        assert res is not None
        assert res['event_type'] == 'PRIVILEGE_CHANGE'
        assert res['username'] == 'sysadmin'

    def test_malformed_line(self, auth_parser):
        line = "This is not a syslog line at all"
        assert not auth_parser.can_parse(line)
        res = auth_parser.parse_line(line)
        assert res is None


class TestLinuxSystemParser:
    def test_service_start(self, system_parser):
        line = "Oct  3 14:20:00 web-server systemd[1]: Started Nginx Web Server"
        assert system_parser.can_parse(line)
        res = system_parser.parse_line(line)
        assert res is not None
        assert res['event_type'] == 'SERVICE_START'
        assert 'Nginx' in res['message']

    def test_service_stop(self, system_parser):
        line = "Oct  3 14:21:00 web-server systemd[1]: Stopped Nginx Web Server"
        res = system_parser.parse_line(line)
        assert res is not None
        assert res['event_type'] == 'SERVICE_STOP'

    def test_suspicious_access(self, system_parser):
        line = "Oct  3 14:22:00 web-server app[999]: Permission denied accessing /etc/shadow"
        res = system_parser.parse_line(line)
        assert res is not None
        assert res['event_type'] == 'SUSPICIOUS_ACCESS'


class TestWindowsSecurityParser:
    def test_login_success_4624(self, windows_parser):
        line = "2026-10-03 14:30:00,4624,Logon,Administrator,192.168.1.100,WIN-DC01,An account was successfully logged on."
        assert windows_parser.can_parse(line)
        res = windows_parser.parse_line(line)
        assert res is not None
        assert res['event_type'] == 'LOGIN_SUCCESS'
        assert res['username'] == 'Administrator'
        assert res['source_ip'] == '192.168.1.100'

    def test_login_failure_4625(self, windows_parser):
        line = "2026-10-03 14:30:05,4625,Logon,Alice,10.0.0.5,WIN-DC01,An account failed to log on."
        res = windows_parser.parse_line(line)
        assert res is not None
        assert res['event_type'] == 'LOGIN_FAILURE'
        assert res['username'] == 'Alice'
        assert res['source_ip'] == '10.0.0.5'

    def test_header_line_ignored(self, windows_parser):
        line = "Timestamp,EventID,EventType,Username,SourceIP,ComputerName,Message"
        res = windows_parser.parse_line(line)
        assert res is None
