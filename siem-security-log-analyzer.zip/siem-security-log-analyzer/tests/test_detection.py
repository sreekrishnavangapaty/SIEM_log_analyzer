"""
Tests for Detection Engine, Rules, and Correlation.
"""
from datetime import datetime, timedelta
import pytest
from app.detection.engine import DetectionEngine
from app.detection.correlation import CorrelationTracker
from app.detection.thresholds import update_threshold, get_thresholds


@pytest.fixture
def engine():
    tracker = CorrelationTracker()
    return DetectionEngine(tracker)


def make_event(event_type, source_ip, username, seconds_ago=0):
    ts = (datetime.utcnow() - timedelta(seconds=seconds_ago)).isoformat()
    return {
        'id': 'test-id',
        'timestamp': ts,
        'source': 'test',
        'event_type': event_type,
        'username': username,
        'source_ip': source_ip,
        'hostname': 'host1',
        'severity': 'LOW',
        'message': 'msg',
        'raw_log': 'raw',
        'created_at': ts
    }


class TestDetectionEngine:
    def test_brute_force_detection(self, engine):
        update_threshold('failed_login_threshold', 5)
        ip = "192.168.10.50"
        user = "admin"

        detections = []
        for i in range(4):
            det = engine.process_event(make_event('LOGIN_FAILURE', ip, user, seconds_ago=10 - i))
            assert len(det) == 0

        # 5th attempt triggers brute force
        det = engine.process_event(make_event('LOGIN_FAILURE', ip, user, seconds_ago=1))
        assert len(det) >= 1
        rule_ids = [d['rule_id'] for d in det]
        assert 'RULE_001' in rule_ids
        bf_det = [d for d in det if d['rule_id'] == 'RULE_001'][0]
        assert bf_det['source_ip'] == ip
        assert bf_det['count'] == 5
        assert 'exceeding the configured threshold of 5' in bf_det['evidence']

    def test_account_enumeration_detection(self, engine):
        update_threshold('account_enum_threshold', 3)
        ip = "192.168.20.70"
        users = ["user1", "user2", "user3"]

        # First 2 users
        for u in users[:2]:
            det = engine.process_event(make_event('LOGIN_FAILURE', ip, u, seconds_ago=10))
            assert not any(d['rule_id'] == 'RULE_002' for d in det)

        # 3rd user triggers enumeration
        det = engine.process_event(make_event('LOGIN_FAILURE', ip, users[2], seconds_ago=2))
        assert any(d['rule_id'] == 'RULE_002' for d in det)
        enum_det = [d for d in det if d['rule_id'] == 'RULE_002'][0]
        assert enum_det['unique_count'] == 3
        assert 'exceeding the configured threshold of 3' in enum_det['evidence']

    def test_suspicious_login_sequence(self, engine):
        update_threshold('suspicious_login_failures_before_success', 3)
        ip = "10.0.0.99"
        user = "victim"

        # 3 failures
        for i in range(3):
            engine.process_event(make_event('LOGIN_FAILURE', ip, user, seconds_ago=30 - i * 5))

        # followed by success
        det = engine.process_event(make_event('LOGIN_SUCCESS', ip, user, seconds_ago=1))
        assert any(d['rule_id'] == 'RULE_003' for d in det)
        susp_det = [d for d in det if d['rule_id'] == 'RULE_003'][0]
        assert susp_det['username'] == user
        assert susp_det['source_ip'] == ip
        assert susp_det['failure_count'] == 3
        assert 'Suspicious authentication sequence' in susp_det['evidence']

    def test_normal_events_no_alerts(self, engine):
        ip = "192.168.1.1"
        user = "normal_user"
        for _ in range(3):
            det = engine.process_event(make_event('LOGIN_SUCCESS', ip, user))
            assert len(det) == 0
