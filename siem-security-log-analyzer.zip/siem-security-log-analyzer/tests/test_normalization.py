"""
Tests for event normalization.
"""
from datetime import datetime
from app.parsers.normalizer import normalize_event, _normalize_timestamp


def test_normalize_timestamp_syslog():
    raw = "Oct  3 14:30:00"
    iso_ts = _normalize_timestamp(raw)
    assert f"{datetime.now().year}" in iso_ts
    assert "14:30:00" in iso_ts


def test_normalize_timestamp_iso():
    raw = "2026-10-03T14:30:00"
    iso_ts = _normalize_timestamp(raw)
    assert iso_ts == raw


def test_normalize_event_full():
    parsed = {
        'timestamp': 'Oct  3 14:30:00',
        'event_type': 'LOGIN_FAILURE',
        'username': 'admin',
        'source_ip': '192.168.1.100',
        'hostname': 'auth-server',
        'process_name': 'sshd',
        'message': 'Failed password for admin'
    }
    raw_line = "Oct  3 14:30:00 auth-server sshd[123]: Failed password for admin from 192.168.1.100"
    event = normalize_event(parsed, 'linux_auth', raw_line)

    assert event is not None
    assert event['source'] == 'linux_auth'
    assert event['event_type'] == 'LOGIN_FAILURE'
    assert event['username'] == 'admin'
    assert event['source_ip'] == '192.168.1.100'
    assert event['hostname'] == 'auth-server'
    assert event['process_name'] == 'sshd'
    assert event['severity'] == 'MEDIUM'
    assert event['raw_log'] == raw_line
    assert 'id' in event
    assert 'created_at' in event


def test_normalize_empty_parsed():
    assert normalize_event({}, 'test', '') is None
    assert normalize_event(None, 'test', '') is None
